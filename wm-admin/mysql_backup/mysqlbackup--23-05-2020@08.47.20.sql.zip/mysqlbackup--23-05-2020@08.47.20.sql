--
-- Database : cintodb
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `access_permissions`
--
DROP TABLE  IF EXISTS `access_permissions`;
CREATE TABLE `access_permissions` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `backup_database` enum('Y','N') NOT NULL DEFAULT 'N',
  `admin_logins` enum('Y','N') NOT NULL DEFAULT 'N',
  `compose_mail` enum('Y','N') NOT NULL DEFAULT 'N',
  `visitor_history` enum('Y','N') NOT NULL DEFAULT 'N',
  `admin_settings` enum('Y','N') NOT NULL DEFAULT 'N',
  `change_password` enum('Y','N') NOT NULL DEFAULT 'N',
  `export_bookings` enum('Y','N') NOT NULL DEFAULT 'N',
  `export_customers` enum('Y','N') NOT NULL DEFAULT 'N',
  `export_labs` enum('Y','N') NOT NULL DEFAULT 'N',
  `export_tests` enum('Y','N') NOT NULL DEFAULT 'N',
  `shutdown` enum('Y','N') NOT NULL DEFAULT 'N',
  `payment_getaway` enum('Y','N') NOT NULL DEFAULT 'N',
  `manage_modarators` enum('Y','N') NOT NULL DEFAULT 'N',
  `manage_permission` enum('Y','N') NOT NULL DEFAULT 'N',
  `test_categories` enum('Y','N') NOT NULL DEFAULT 'N',
  `add_tests` enum('Y','N') NOT NULL DEFAULT 'N',
  `manage_tests` enum('Y','N') NOT NULL DEFAULT 'N',
  `featured_tests` enum('Y','N') NOT NULL DEFAULT 'N',
  `upload_report` enum('Y','N') NOT NULL DEFAULT 'N',
  `pending_reports` enum('Y','N') NOT NULL DEFAULT 'N',
  `inprogress_reports` enum('Y','N') NOT NULL DEFAULT 'N',
  `cancelled_reports` enum('Y','N') NOT NULL DEFAULT 'N',
  `delivered_reports` enum('Y','N') NOT NULL DEFAULT 'N',
  `add_customer` enum('Y','N') NOT NULL DEFAULT 'N',
  `active_customers` enum('Y','N') NOT NULL DEFAULT 'N',
  `inactive_customers` enum('Y','N') NOT NULL DEFAULT 'N',
  `add_lab` enum('Y','N') NOT NULL DEFAULT 'N',
  `active_lab` enum('Y','N') NOT NULL DEFAULT 'N',
  `inactive_lab` enum('Y','N') NOT NULL DEFAULT 'N',
  `lab_bookings` enum('Y','N') NOT NULL DEFAULT 'N',
  `lab_earnings` enum('Y','N') NOT NULL DEFAULT 'N',
  `lab_reports` enum('Y','N') NOT NULL DEFAULT 'N',
  `create_posts` enum('Y','N') NOT NULL DEFAULT 'N',
  `manage_posts` enum('Y','N') NOT NULL DEFAULT 'N',
  `add_faq` enum('Y','N') NOT NULL DEFAULT 'N',
  `manage_faq` enum('Y','N') NOT NULL DEFAULT 'N',
  `all_bookings` enum('Y','N') NOT NULL DEFAULT 'N',
  `search_bookings` enum('Y','N') NOT NULL DEFAULT 'N',
  `control_panel` enum('Y','N') NOT NULL DEFAULT 'N',
  `comment` text NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `access_permissions`  VALUES ( "1","1","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","");
INSERT INTO `access_permissions`  VALUES ( "5","3","Y","Y","Y","Y","","Y","","","","","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y","","");


--
-- Tabel structure for table `admin_group`
--
DROP TABLE  IF EXISTS `admin_group`;
CREATE TABLE `admin_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(256) NOT NULL,
  `administrator` enum('Y','N') NOT NULL DEFAULT 'N',
  `all_users` enum('Y','N') NOT NULL DEFAULT 'Y',
  `configuration` enum('Y','N') NOT NULL DEFAULT 'Y',
  `job_posting` enum('Y','N') NOT NULL DEFAULT 'N',
  `company_profiles` enum('Y','N') NOT NULL DEFAULT 'N',
  `membership` enum('Y','N') NOT NULL DEFAULT 'Y',
  `transaction` enum('Y','N') NOT NULL DEFAULT 'Y',
  `cms_pages` enum('Y','N') NOT NULL DEFAULT 'Y',
  `blog_management` enum('Y','N') NOT NULL DEFAULT 'Y',
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `admin_group`  VALUES ( "1","Order Processors","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y");
INSERT INTO `admin_group`  VALUES ( "2","Sales Team","","Y","","Y","","","","","","Y");
INSERT INTO `admin_group`  VALUES ( "4","HR Management","Y","Y","","Y","Y","","Y","","Y","Y");
INSERT INTO `admin_group`  VALUES ( "5","Support Team","N","Y","N","Y","N","Y","Y","Y","Y","Y");
INSERT INTO `admin_group`  VALUES ( "7","Web Developer","Y","Y","Y","Y","Y","Y","Y","Y","Y","Y");
INSERT INTO `admin_group`  VALUES ( "8","Admin Group","","Y","Y","Y","Y","Y","Y","Y","Y","Y");
INSERT INTO `admin_group`  VALUES ( "9","TestGroup","","","","","","Y","","","","Y");


--
-- Tabel structure for table `admin_lastlogin`
--
DROP TABLE  IF EXISTS `admin_lastlogin`;
CREATE TABLE `admin_lastlogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminid` int(11) NOT NULL,
  `timestamp` varchar(256) NOT NULL,
  `again` varchar(256) NOT NULL,
  `IP` varchar(256) NOT NULL,
  `browser` varchar(256) NOT NULL,
  `OS` varchar(256) NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=168 DEFAULT CHARSET=latin1;

INSERT INTO `admin_lastlogin`  VALUES ( "1","1","08 Jan, 2018 22:45 PM","Yes","172.68.146.59","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0","Direct access","08 January, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "2","1","10 Jan, 2018 3:13 AM","Yes","203.171.246.94","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","Direct access","10 January, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "3","1","10 Jan, 2018 3:35 AM","Yes","203.171.246.94","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","Direct access","10 January, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "4","1","10 Jan, 2018 6:46 AM","Yes","203.171.246.94","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","Direct access","10 January, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "5","1","10 Jan, 2018 10:00 AM","Yes","203.171.246.94","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","Direct access","10 January, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "6","1","11 Jan, 2018 0:08 AM","Yes","202.142.113.42","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","Direct access","11 January, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "7","1","11 Jan, 2018 0:35 AM","Yes","203.171.246.94","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","Direct access","11 January, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "8","1","12 Jan, 2018 1:05 AM","Yes","203.171.246.94","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","Direct access","12 January, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "9","1","30 Jan, 2018 9:17 AM","Yes","203.171.246.94","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","Direct access","30 January, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "10","1","30 Jan, 2018 23:52 PM","Yes","203.171.246.94","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","Direct access","30 January, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "11","1","31 Jan, 2018 0:44 AM","Yes","203.171.246.94","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","Direct access","31 January, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "12","1","01 Feb, 2018 0:00 AM","Yes","203.171.246.94","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","Direct access","01 February, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "13","1","02 Feb, 2018 1:35 AM","Yes","203.171.246.94","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","Direct access","02 February, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "14","1","02 Feb, 2018 2:05 AM","Yes","203.171.246.94","Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0","Direct access","02 February, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "15","1","08 Feb, 2018 6:33 AM","Yes","116.193.138.9","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36","Direct access","08 February, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "16","1","14 Feb, 2018 1:42 AM","Yes","116.193.138.9","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36","Direct access","14 February, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "17","1","14 Feb, 2018 5:18 AM","Yes","116.193.138.9","Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0","Direct access","14 February, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "18","1","14 Feb, 2018 9:19 AM","Yes","116.193.138.9","Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0","Direct access","14 February, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "19","1","15 Feb, 2018 0:38 AM","Yes","116.193.138.9","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36","Direct access","15 February, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "20","1","15 Feb, 2018 6:47 AM","Yes","116.193.138.9","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","Direct access","15 February, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "21","1","16 Feb, 2018 2:16 AM","Yes","116.193.138.9","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36","Direct access","16 February, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "22","1","19 Feb, 2018 7:19 AM","Yes","116.193.138.9","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","Direct access","19 February, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "23","1","27 Feb, 2018 13:37 PM","Yes","202.142.69.103","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36","Direct access","27 February, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "24","1","28 Feb, 2018 13:41 PM","Yes","202.142.113.140","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36","Direct access","28 February, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "25","1","14 Mar, 2018 8:08 AM","Yes","202.142.69.82","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36","Direct access","14 March, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "26","1","01 May, 2018 21:13 PM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","Direct access","01 May, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "27","1","02 May, 2018 6:32 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","Direct access","02 May, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "28","1","02 May, 2018 6:44 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","Direct access","02 May, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "29","1","02 May, 2018 6:45 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","Direct access","02 May, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "30","1","02 May, 2018 6:45 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","Direct access","02 May, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "31","1","02 May, 2018 7:15 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","Direct access","02 May, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "32","1","02 May, 2018 7:17 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","Direct access","02 May, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "33","1","09 May, 2018 21:27 PM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","Direct access","09 May, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "34","1","10 May, 2018 6:25 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","Direct access","10 May, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "35","1","11 May, 2018 19:50 PM","Yes","127.0.0.1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","Direct access","11 May, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "36","1","12 May, 2018 10:31 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","Direct access","12 May, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "37","1","14 May, 2018 5:06 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36","Direct access","14 May, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "38","1","29 Jul, 2018 20:20 PM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","Direct access","29 July, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "39","1","29 Jul, 2018 20:44 PM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","Direct access","29 July, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "40","1","30 Jul, 2018 6:50 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","Direct access","30 July, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "41","1","16 Aug, 2018 20:38 PM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36","Direct access","16 August, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "42","1","17 Aug, 2018 6:09 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36","Direct access","17 August, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "43","1","15 Sep, 2018 22:09 PM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36","Direct access","15 September, 2018","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "44","1","16 Jan, 2019 19:17 PM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36","Direct access","16 January, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "45","1","10 Feb, 2019 8:00 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.96 Safari/537.36","Direct access","10 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "46","1","10 Feb, 2019 8:10 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.96 Safari/537.36","Direct access","10 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "47","1","10 Feb, 2019 11:49 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.96 Safari/537.36","Direct access","10 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "48","1","10 Feb, 2019 12:03 PM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.96 Safari/537.36","Direct access","10 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "49","1","17 Feb, 2019 21:48 PM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36","Direct access","17 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "50","1","23 Feb, 2019 6:47 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36","Direct access","23 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "51","1","23 Feb, 2019 7:13 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36","Direct access","23 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "52","1","23 Feb, 2019 8:10 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36","Direct access","23 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "53","1","23 Feb, 2019 9:42 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36","Direct access","23 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "54","1","24 Feb, 2019 11:14 AM","Yes","::1","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36","Direct access","24 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "55","1","25 Feb, 2019 8:41 AM","Yes","47.15.160.71","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36","Direct access","25 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "56","1","25 Feb, 2019 13:13 PM","Yes","202.142.68.151","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36","Direct access","25 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "57","1","25 Feb, 2019 14:02 PM","Yes","202.142.68.151","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36","Direct access","25 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "58","1","25 Feb, 2019 15:40 PM","Yes","202.142.68.151","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36","Direct access","25 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "59","1","26 Feb, 2019 20:06 PM","Yes","213.127.69.214","Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36","Direct access","26 February, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "60","1","04 Mar, 2019 16:41 PM","Yes","202.142.68.151","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36","Direct access","04 March, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "61","1","04 Mar, 2019 16:49 PM","Yes","202.142.68.151","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36","Direct access","04 March, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "62","1","05 Mar, 2019 12:06 PM","Yes","202.142.68.151","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36","Direct access","05 March, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "63","1","05 Mar, 2019 14:02 PM","Yes","202.142.68.151","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36","Direct access","05 March, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "64","1","14 Mar, 2019 20:41 PM","Yes","31.161.193.27","Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36","Direct access","14 March, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "65","1","24 Mar, 2019 12:00 PM","Yes","213.127.25.216","Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36","Direct access","24 March, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "66","1","24 Mar, 2019 18:29 PM","Yes","213.127.25.216","Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36","Direct access","24 March, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "67","1","02 Apr, 2019 20:05 PM","Yes","202.142.69.213","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36","Direct access","02 April, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "68","1","02 Apr, 2019 23:28 PM","Yes","213.127.23.18","Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36","Direct access","02 April, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "69","1","08 Apr, 2019 4:33 AM","Yes","202.142.69.213","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36","Direct access","08 April, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "70","1","08 Apr, 2019 6:02 AM","Yes","202.142.68.151","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36","Direct access","08 April, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "71","1","08 Apr, 2019 8:20 AM","Yes","202.142.68.151","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36","Direct access","08 April, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "72","1","17 Apr, 2019 21:36 PM","Yes","213.127.6.154","Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36","Direct access","17 April, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "73","1","17 Apr, 2019 23:00 PM","Yes","213.127.27.69","Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36","Direct access","17 April, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "74","1","26 May, 2019 9:46 AM","Yes","213.127.26.39","Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36","Direct access","26 May, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "75","1","26 May, 2019 16:44 PM","Yes","213.127.26.39","Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36","Direct access","26 May, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "76","1","28 May, 2019 3:24 AM","Yes","202.142.69.222","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36","Direct access","28 May, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "77","1","28 May, 2019 3:28 AM","Yes","202.142.69.222","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36","Direct access","28 May, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "78","1","28 May, 2019 3:45 AM","Yes","202.142.69.222","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36","Direct access","28 May, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "79","1","28 May, 2019 4:45 AM","Yes","202.142.69.222","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36","Direct access","28 May, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "80","1","30 May, 2019 19:28 PM","Yes","213.127.26.39","Mozilla/5.0 (X11; CrOS x86_64 10718.88.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.118 Safari/537.36","Direct access","30 May, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "81","1","30 May, 2019 20:08 PM","Yes","213.127.26.39","Mozilla/5.0 (X11; CrOS x86_64 10718.88.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.118 Safari/537.36","Direct access","30 May, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "82","1","01 Jun, 2019 13:31 PM","Yes","31.161.148.124","Mozilla/5.0 (Linux; Android 9; SM-G955F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Mobile Safari/537.36","Direct access","01 June, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "83","1","02 Jun, 2019 4:54 AM","Yes","202.142.69.136","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36","Direct access","02 June, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "84","1","02 Jun, 2019 5:44 AM","Yes","202.142.69.136","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36","Direct access","02 June, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "85","1","03 Jun, 2019 8:37 AM","Yes","89.255.59.254","Mozilla/5.0 (X11; CrOS x86_64 10718.88.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.118 Safari/537.36","Direct access","03 June, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "86","1","10 Jun, 2019 1:14 AM","Yes","213.127.26.39","Mozilla/5.0 (X11; CrOS x86_64 11895.118.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.159 Safari/537.36","Direct access","10 June, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "87","1","13 Jun, 2019 17:59 PM","Yes","89.255.59.254","Mozilla/5.0 (X11; CrOS x86_64 11895.118.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.159 Safari/537.36","Direct access","13 June, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "88","1","26 Jun, 2019 22:49 PM","Yes","213.127.26.12","Mozilla/5.0 (X11; CrOS x86_64 11895.118.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.159 Safari/537.36","Direct access","26 June, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "89","1","02 Jul, 2019 5:30 AM","Yes","202.142.113.24","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36","Direct access","02 July, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "90","1","02 Jul, 2019 5:44 AM","Yes","202.142.113.24","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36","Direct access","02 July, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "91","1","02 Jul, 2019 5:51 AM","Yes","202.142.113.24","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36","Direct access","02 July, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "92","1","25 Jul, 2019 12:39 PM","Yes","202.142.113.100","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36","Direct access","25 July, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "93","1","25 Jul, 2019 12:48 PM","Yes","202.142.113.100","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36","Direct access","25 July, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "94","1","29 Jul, 2019 4:26 AM","Yes","202.142.113.164","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36","Direct access","29 July, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "95","1","20 Aug, 2019 17:10 PM","Yes","202.142.113.121","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36","Direct access","20 August, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "96","1","21 Aug, 2019 9:00 AM","Yes","202.142.95.2","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36","Direct access","21 August, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "97","1","21 Aug, 2019 16:50 PM","Yes","202.142.95.62","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36","Direct access","21 August, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "98","1","22 Aug, 2019 4:34 AM","Yes","202.142.113.138","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36","Direct access","22 August, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "99","1","22 Aug, 2019 12:48 PM","Yes","202.142.113.108","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36","Direct access","22 August, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "100","1","22 Aug, 2019 17:49 PM","Yes","202.142.113.101","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36","Direct access","22 August, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "101","1","22 Aug, 2019 18:53 PM","Yes","202.142.113.101","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36","Direct access","22 August, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "102","1","22 Aug, 2019 19:27 PM","Yes","184.224.223.212","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1.2 Safari/605.1.15","Direct access","22 August, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "103","1","22 Aug, 2019 19:53 PM","Yes","66.87.142.158","Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-N950U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/9.2 Chrome/67.0.3396.87 Mobile Safari/537.36","Direct access","22 August, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "104","1","22 Aug, 2019 23:12 PM","Yes","66.87.142.158","Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-N950U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/9.2 Chrome/67.0.3396.87 Mobile Safari/537.36","Direct access","22 August, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "105","1","23 Aug, 2019 5:05 AM","Yes","202.142.95.89","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36","Direct access","23 August, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "106","1","23 Aug, 2019 17:58 PM","Yes","202.142.113.104","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36","Direct access","23 August, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "107","1","24 Aug, 2019 19:40 PM","Yes","202.142.113.244","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36","Direct access","24 August, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "108","0","05 Sep, 2019 19:37 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","05 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "109","0","05 Sep, 2019 19:37 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","05 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "110","0","05 Sep, 2019 19:38 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","05 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "111","0","05 Sep, 2019 19:38 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","05 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "112","0","05 Sep, 2019 19:40 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","05 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "113","0","05 Sep, 2019 19:40 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","05 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "114","0","05 Sep, 2019 19:40 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","05 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "115","0","05 Sep, 2019 19:41 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","05 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "116","0","05 Sep, 2019 19:41 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","05 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "117","1","05 Sep, 2019 19:43 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","05 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "118","1","05 Sep, 2019 19:56 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","05 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "119","1","06 Sep, 2019 6:09 AM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","06 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "120","1","06 Sep, 2019 11:02 AM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","06 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "121","1","10 Sep, 2019 20:46 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","10 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "122","1","11 Sep, 2019 20:48 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","11 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "123","1","12 Sep, 2019 9:32 AM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","12 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "124","1","13 Sep, 2019 9:45 AM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","13 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "125","1","13 Sep, 2019 19:32 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","13 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "126","1","14 Sep, 2019 6:50 AM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","14 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "127","1","14 Sep, 2019 7:56 AM","Yes","202.142.95.38","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","14 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "128","1","14 Sep, 2019 11:31 AM","Yes","42.110.144.90","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0","Direct access","14 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "129","1","14 Sep, 2019 11:31 AM","Yes","42.110.144.90","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0","Direct access","14 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "130","1","17 Sep, 2019 11:43 AM","Yes","129.41.164.81","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0","Direct access","17 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "131","1","17 Sep, 2019 15:55 PM","Yes","117.194.233.138","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0","Direct access","17 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "132","1","24 Sep, 2019 15:33 PM","Yes","150.107.213.230","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0","Direct access","24 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "133","1","25 Sep, 2019 17:40 PM","Yes","202.142.113.157","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36","Direct access","25 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "134","1","25 Sep, 2019 18:41 PM","Yes","202.142.113.157","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36","Direct access","25 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "135","1","25 Sep, 2019 19:36 PM","Yes","202.142.113.157","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36","Direct access","25 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "136","1","25 Sep, 2019 20:18 PM","Yes","202.142.113.157","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36","Direct access","25 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "137","1","26 Sep, 2019 3:40 AM","Yes","202.142.113.157","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36","Direct access","26 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "138","1","26 Sep, 2019 4:58 AM","Yes","202.142.113.157","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36","Direct access","26 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "139","1","28 Sep, 2019 4:31 AM","Yes","202.142.95.10","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36","Direct access","28 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "140","1","28 Sep, 2019 4:55 AM","Yes","202.142.95.10","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36","Direct access","28 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "141","1","28 Sep, 2019 8:10 AM","Yes","202.142.95.10","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36","Direct access","28 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "142","1","28 Sep, 2019 8:54 AM","Yes","202.142.95.10","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36","Direct access","28 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "143","1","28 Sep, 2019 18:20 PM","Yes","202.142.95.10","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36","Direct access","28 September, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "144","1","15 Oct, 2019 17:42 PM","Yes","202.142.113.250","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36","Direct access","15 October, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "145","1","08 Nov, 2019 21:41 PM","Yes","202.142.95.203","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36","Direct access","08 November, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "146","1","09 Nov, 2019 5:23 AM","Yes","202.142.95.101","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36","Direct access","09 November, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "147","1","09 Nov, 2019 8:26 AM","Yes","202.142.95.101","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36","Direct access","09 November, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "148","1","09 Nov, 2019 9:21 AM","Yes","202.142.95.101","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36","Direct access","09 November, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "149","1","09 Nov, 2019 10:01 AM","Yes","202.142.95.101","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36","Direct access","09 November, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "150","1","09 Nov, 2019 10:05 AM","Yes","202.142.95.101","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36","Direct access","09 November, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "151","1","10 Nov, 2019 13:24 PM","Yes","202.142.95.120","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36","Direct access","10 November, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "152","1","06 Dec, 2019 7:49 AM","Yes","103.225.177.32","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36","Direct access","06 December, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "153","1","24 Dec, 2019 20:06 PM","Yes","141.101.98.171","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","24 December, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "154","1","25 Dec, 2019 18:57 PM","Yes","162.158.158.8","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","25 December, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "155","1","26 Dec, 2019 4:21 AM","Yes","162.158.166.22","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","26 December, 2019","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "156","1","03 Mar, 2020 5:02 AM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36","Direct access","03 March, 2020","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "157","1","03 Mar, 2020 22:29 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36","Direct access","03 March, 2020","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "158","1","12 Apr, 2020 23:25 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36","Direct access","12 April, 2020","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "159","1","12 Apr, 2020 23:26 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36","Direct access","12 April, 2020","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "160","1","12 Apr, 2020 23:28 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36","Direct access","12 April, 2020","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "161","1","12 Apr, 2020 23:33 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36","Direct access","12 April, 2020","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "162","1","21 May, 2020 14:38 PM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36","Direct access","21 May, 2020","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "163","1","22 May, 2020 9:10 AM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36","Direct access","22 May, 2020","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "164","1","22 May, 2020 10:16 AM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36","Direct access","22 May, 2020","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "165","1","23 May, 2020 8:13 AM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36","Direct access","23 May, 2020","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "166","3","23 May, 2020 8:34 AM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36","Direct access","23 May, 2020","Y");
INSERT INTO `admin_lastlogin`  VALUES ( "167","1","23 May, 2020 8:35 AM","Yes","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36","Direct access","23 May, 2020","Y");


--
-- Tabel structure for table `admin_login`
--
DROP TABLE  IF EXISTS `admin_login`;
CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(256) NOT NULL,
  `lastname` varchar(256) NOT NULL,
  `department` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `user_pic` text NOT NULL,
  `username` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `country` varchar(100) NOT NULL,
  `modaratorid` int(11) NOT NULL,
  `type` enum('A','M','S') NOT NULL DEFAULT 'S',
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `datetime` varchar(100) NOT NULL,
  `active_account` text NOT NULL,
  `forgot_password_token` text NOT NULL,
  `social_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `admin_login`  VALUES ( "1","super","admin","Super Admin","info@jobsire.com","358460Koala.jpg","admin","0192023a7bbd73250516f069df18b500","105","0","A","Y","22 May, 2020","","","");
INSERT INTO `admin_login`  VALUES ( "3","Anuj","Agarwal","Business Executive","interanuj2004@gmail.com","","interanuj","0192023a7bbd73250516f069df18b500","105","0","M","Y","22 May, 2020","","","");


--
-- Tabel structure for table `backupdb`
--
DROP TABLE  IF EXISTS `backupdb`;
CREATE TABLE `backupdb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(256) NOT NULL,
  `date` varchar(256) NOT NULL,
  `filesize` varchar(256) NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `category`
--
DROP TABLE  IF EXISTS `category`;
CREATE TABLE `category` (
  `cat_id` int(2) NOT NULL AUTO_INCREMENT,
  `category` varchar(25) NOT NULL DEFAULT '',
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

INSERT INTO `category`  VALUES ( "1","Deals of the Day","Y");
INSERT INTO `category`  VALUES ( "2","Top Stores","Y");
INSERT INTO `category`  VALUES ( "3","Fashion","Y");
INSERT INTO `category`  VALUES ( "5","Travel","Y");
INSERT INTO `category`  VALUES ( "6","Recharge","Y");
INSERT INTO `category`  VALUES ( "7","Movies Booking","Y");
INSERT INTO `category`  VALUES ( "8","Medicine","Y");


--
-- Tabel structure for table `clinto_labs`
--
DROP TABLE  IF EXISTS `clinto_labs`;
CREATE TABLE `clinto_labs` (
  `labid` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(256) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `alternative` varchar(100) NOT NULL,
  `email` varchar(256) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `pincode` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `datetime` varchar(50) NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`labid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `clinto_labs`  VALUES ( "1","Suraksha Diagonostics","8961311235","dfgdfg","tamalbagchi@gmail.com","BH19/C Tirupati Apt.","Kolkata","700102","23 May, 2020","2020-05-23 20:04:43","Y");


--
-- Tabel structure for table `clinto_tests`
--
DROP TABLE  IF EXISTS `clinto_tests`;
CREATE TABLE `clinto_tests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(256) NOT NULL,
  `test_name` varchar(256) NOT NULL,
  `regular_fee` varchar(256) NOT NULL,
  `sale_fee` varchar(256) NOT NULL,
  `instructions` varchar(256) NOT NULL,
  `test_contains` varchar(256) NOT NULL,
  `test_picture` varchar(256) NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'N',
  `featured` varchar(10) NOT NULL,
  `date` varchar(256) NOT NULL,
  `datetime` varchar(256) NOT NULL,
  `last_updated` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=367224 DEFAULT CHARSET=latin1;

INSERT INTO `clinto_tests`  VALUES ( "367223","3","213","321","554","654","564","8f6402c9d87da40f2f92463ad36b75aa60b7b0db-5e09-44df-8a8f-9edabce43610.jpg","Y","Y","23 May, 2020","2020-05-23 09:48:29","2020-05-23 09:48:29");


--
-- Tabel structure for table `contacts`
--
DROP TABLE  IF EXISTS `contacts`;
CREATE TABLE `contacts` (
  `support_id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `phone` varchar(256) NOT NULL,
  `social_profile` text NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `ip` varchar(256) NOT NULL,
  `date` varchar(256) NOT NULL,
  `datetime` varchar(256) NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`support_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `contacts`  VALUES ( "1","Tamal Bagchi","tamalbagchi@gmail.com","08961311235","https://instagram.com/angad2339","Request to downgrade my Membership Plan","fdgfdgdfg dfgfd","172.69.135.211","13 December, 2019","2019-12-12 21:45:29","N");
INSERT INTO `contacts`  VALUES ( "2","Tamal Bagchi","tamalbagchi@gmail.com","08961311235","https://instagram.com/angad2339","Request to downgrade my Membership Plan","Your MessageYour MessageYour MessageYour MessageYour Message","172.69.135.211","13 December, 2019","2019-12-12 21:46:18","N");
INSERT INTO `contacts`  VALUES ( "3","Tamal Bagchi","tamalbagchi@gmail.com","08961311235","BH19/C Tirupati Apt., Jodakhana, Kestopur","Request to downgrade my Membership Plan","ghjhgjgh jhgjgh jghj gh","172.69.134.158","13 December, 2019","2019-12-12 21:55:48","N");
INSERT INTO `contacts`  VALUES ( "4","MarkReuch","freemanweeman@probbox.com ","82117497842","https://elimite2.com/ ","vgxdcdkzl","<a href="https://elimite2.com/">where to buy elimite cream over the counter</a> ","172.69.10.63","17 December, 2019","2019-12-16 20:23:25","N");
INSERT INTO `contacts`  VALUES ( "5","LisaReuch","keith50hainsworth@probbox.com ","86342122766","http://elimite2.com/ ","lksssbrso","<a href="http://emrcgroup.org/6-700x300/?unapproved=24&moderation-hash=9d35841a21236bab6e8d361d8677ebb5">accexur</a> 
<a href="https://www.creatiefpaultje.nl/?unapproved=182728&moderation-hash=e9cdfe63fba90adf8ee99b2d372ffdb8">gptelix</a> 
<a href="https://oileain.ie/na-hoileain-the-islands/map_english/?unapproved=64048&moderation-hash=1a19658725fd8c015c49610594526aa7">mkowphw</a> 
<a href="http://mendozamotorsco.com/producto/triciclo-para-discapacitados-con-vidrio-frontal/">snxfkrq</a> 
<a href="https://www.chessiefcu.org/home/in-process_inthecity/?unapproved=193&moderation-hash=ef9fbb55debb971dca165a332a4f0968">bgiwxtr</a> 
<a href="https://nazaredopico.com.br/blog/2019/12/01/nfc/?unapproved=2945&moderation-hash=8f04257cff04852f793281d666fb1771">yfavfvm</a> 
<a href="https://www.asteriot.fr/produit/horizon-strip-tshirt/?unapproved=47181&moderation-hash=c1c9dd8850d86b03c6d267f4ae73114c">vxtrtrd</a> 
<a href="https://spadet.com/a-mothers-legacy/?unapproved=82507&moderation-hash=f1a55b25564e275dbe714c2424d989e2">rjbfqcj</a> 
<a href="http://dffenglish.com/2015/10/20/ogrenci-yorumlari-4/?unapproved=572&moderation-hash=c8e533d6515e98355a3bfb635b06f644">hpmciau</a> 
<a href="https://www.dlaxn.de/news/regelwahnsinn-im-deutschen-lacrosse/?unapproved=9944&moderation-hash=671e9ba693bfbcaa33bca5a008e37b3e">agulmlp</a>","172.69.10.99","20 December, 2019","2019-12-20 07:47:21","N");
INSERT INTO `contacts`  VALUES ( "6","MaryReuch","andersljung2@probbox.com ","86614562383","https://elimite2.com/ ","ozcmigomt","<a href="https://elimite2.com/">generic elimite cream price</a> ","172.69.10.63","20 December, 2019","2019-12-20 08:26:49","N");
INSERT INTO `contacts`  VALUES ( "7","Emeryalarm","inbox400@glmux.com","84719697158","https://helpwritingcollegeessays871.blogspot.com/2019/08/apocalypse-now-review-essay-essays.html","Save me from remaking all these from the beginning please ((","   There are a lot of essay crafting companies that contemplate they are really on best, so do not be | Should you want to acquire higher excellent quality groundwork and thesis papers by the due date.
 
https://bestessays-2013.blogspot.com/2018/07/poetry-analysis-in-mrs-tilschers-class.html
https://phddissertationwritingservices1.blogspot.com/2019/08/ladership-in-customer-service-article.html
https://professionalessaywriters10.blogspot.com/2019/07/speaker-responce-assignment-example.html
https://essaywritingprompts483.blogspot.com/2019/11/comparing-and-contrasting-two.html
https://goodessaysample550.blogspot.com/2019/11/top-10-grammatical-and-spelling-errors.html
https://essaywritingservicesreview343.blogspot.com/2019/08/effects-of-peer-pressure-on-decision.html
https://pumpkinwritingpaper.blogspot.com/2019/06/life-in-universe-significance-of-planet.html
https://alienwritingpaper1.blogspot.com/2019/11/ideas-and-beliefs-in-justine.html
https://relevantcourseworkdefinition12.blogspot.com/2019/10/assignments-essay-example-topics-and.html
https://bestcustompaper.blogspot.com/2017/09/why-are-some-pregnant-women-afraid-of.html
https://extendedessaytopicideas.blogspot.com/2019/08/macroeconomic-influences-and-future.html
https://writeanessayonline.blogspot.com/2016/07/trust.html
https://tutoressaywriting.blogspot.com/2019/06/case-study-boeing-aircraft-company.html
https://freesamplethesispaper.blogspot.com/2017/02/smoking-cigarettes-causes-accelerated.html
https://freesamplethesispaper.blogspot.com/2014/01/ideals-satirized-in-candide.html
https://writinganadvertisement.blogspot.com/2019/10/truth-is-it-good-or-evil-essay-essays.html
https://researchpapersforsale820.blogspot.com/2019/10/a-portrait-of-artist-as-young-man.html
https://professionalessaywriters254.blogspot.com/2019/10/government-contracting-coursework.html
https://howtomakeessayexample193.blogspot.com/2019/10/a-strategic-plan-of-hong-kong.html
https://writeananalyticalessay896.blogspot.com/2019/07/genetically-modified-food-essay-example.html
https://blankwritingpaperforkindergarten.blogspot.com/2019/07/role-of-high-frequency-trading-in.html
https://howdowewriteessay.blogspot.com/2019/09/becoming-medical-billing-specialist.html
https://academicwritingessays2.blogspot.com/2019/06/study-of-chinese-wine-consumption-essay.html
https://definitionofessaywriting287.blogspot.com/2019/06/stop-frisk-essay-example-for-free.html
https://collegeapplicationessay881.blogspot.com/2019/09/the-communication-process-essay-example.html
https://universityessaywriting973.blogspot.com/2019/10/an-analysis-of-peopleaaas-history-of.html
https://reasonstogotocollegeessay.blogspot.com/2019/07/a-clockwork-orange-summary.html
https://bestessays-2013.blogspot.com/2013/11/concept-of-change-looking-for-alibrandi.html
https://cheap-speech-topics.blogspot.com/2018/03/wanting-to-hail-rough-sketch-online.html
https://coldwaressay-us.blogspot.com/2016/01/mobile-success-blueprints-research.html
https://literaryessay563.blogspot.com/2019/06/lighting-design-makes-stage-real-and.html
https://essaywritingguide714.blogspot.com/2019/07/internal-selling-aaaputting-theory-into.html
https://eeibtopics.blogspot.com/2019/07/love-or-friendship-essay.html
https://argumentessaysonabortion.blogspot.com/2019/09/dominoes-vs-pizza-hut-essay-example-for.html
https://harvardcollegeessay.blogspot.com/2019/07/engliash-essay-example-topics-and-well.html
https://ineedsomeonetowriteapaperforme.blogspot.com/2018/06/healing-with-whole-foods.html
https://goodessayconclusions.blogspot.com/2019/10/idi-amin.html
https://buyspeech347.blogspot.com/2019/10/global-blog-project-essay-example.html
https://customessaysonline470.blogspot.com/2019/11/international-marketing-coursework.html
https://bestessays-2013.blogspot.com/2019/10/combining-fact-and-fiction-in-writing.html
https://writemyessayforme1.blogspot.com/2019/03/the-great-gatsby-is-nick-who-makes-jay.html
https://buyexpositoryessays.blogspot.com/2019/09/critical-analysis-of-college-is-waste.html
https://cheap-800-word-essay-example.blogspot.com/2019/08/application-assignment.html
https://articlewritingtips1.blogspot.com/2019/09/meaning-of-mobile-banking-information.html
https://goodcollegeapplicationessays335.blogspot.com/2019/10/australia-essay-essays-research-papers.html
https://helpwritingcollegeessays871.blogspot.com/2019/08/jeannette-winterson-weight.html
https://mymotheressaywriting198.blogspot.com/2019/10/kmf-project.html
https://textualanalysisoutline.blogspot.com/2019/11/a-dolls-house-essays-337-words-ibsen.html
https://cheapessaywritingservice416.blogspot.com/2019/09/dance-assignment-example-topics-and.html
https://onlinepaperwritingservice.blogspot.com/2013/11/westward-expansion.html
https://advertisementanalysisexamples.blogspot.com/2019/08/drivers-of-recent-wave-of-globalisation.html
https://buyaresearchpaperinapaformat.blogspot.com/2018/05/hard-working-america.html
https://bookreport12345.blogspot.com/2019/05/how-to-control-over-population-country.html
https://endnotesapaformat.blogspot.com/2019/09/belonging-to-community-essay.html
https://writeanessayonline.blogspot.com/2018/03/bora-bora-vacations-enchanting-vacation.html
https://importanceofwritingaresearchpaper12.blogspot.com/2019/08/hr-practices-and-policies-with.html
https://mlaresearchpaper946.blogspot.com/2019/09/health-and-safety-regulation-in.html
https://howtostartanessaywithaquote.blogspot.com/2019/06/summary-of-council-meeting-essay.html
https://biographywritingpaper616.blogspot.com/2019/08/a-psychological-history-of-german-film.html
https://someonetowritemypaper488.blogspot.com/2019/10/hnd-in-business-accounting-management.html
https://freesamplethesispaper.blogspot.com/2016/06/buying-business-plan-template-to-jump.html
https://howtowriteaobservationpaper468.blogspot.com/2019/09/reflections-of-communist-manifesto-and.html
https://writemyessayreviews433.blogspot.com/2019/08/application-assignment.html
https://howtowritinganessay125.blogspot.com/2019/08/prospects-and-problems-of-biomass.html
https://annotatedbibliographytopics.blogspot.com/2019/09/respond-to-question-2-on-attach.html
https://howcaniwriteessayinenglish.blogspot.com/2019/10/whether-or-not-there-would-be-time-to.html
https://buyessay-cheap.blogspot.com/2013/12/training-program-design-and-development.html
https://bookcritiqueexampleessay2.blogspot.com/2019/08/the-holy-ghost-essay-example-topics-and.html
https://originalessay647.blogspot.com/2019/08/historical-chronology-essay.html
https://graduateadmissionessay308.blogspot.com/2019/08/polonius-is-good-father-in-hamlet.html
https://writemyessayforme629.blogspot.com/2019/07/concentrated-solar-power-essay-example.html
https://mbaadmissionessay406.blogspot.com/2019/09/free-awakening-essays-analysis-of.html
https://writemyessay-s.blogspot.com/2013/12/culture-and-values-of-texts-morte.html
https://customwritingtips.blogspot.com/2019/05/the-pros-and-cons-of-belmont-honor-code.html
https://cheapargumentativeessaytopicsideas.blogspot.com/2019/07/effects-of-training-and-development-on.html
https://paperwritinghelp1.blogspot.com/2019/05/madness-essays-papers.html
https://bestcustompaper.blogspot.com/2015/12/male-strippers.html
https://howdoiwriteanessay123.blogspot.com/2019/09/the-current-heritage-conservation.html
https://a-p-a-format.blogspot.com/2014/01/civil-war.html
https://bestcustompaper.blogspot.com/2015/10/to-error-is-human.html
https://essaywritingpaper410.blogspot.com/2019/08/the-definition-of-independence.html
https://howtowriteapaperoutline.blogspot.com/2017/01/save-money-using-novated-lease.html
https://writemytermpaper892.blogspot.com/2019/08/diversity-at-nih-research-paper-example.html
https://writingaphilosophypaper12.blogspot.com/2019/12/qualities-of-strong-teenage-girl-free.html
https://howtowriteessaysincollege911.blogspot.com/2019/10/riordanaaas-competitive-advantages.html
https://criticalargumentessay2.blogspot.com/2019/10/philosophy-of-education-essay-example.html
https://paperwritingjobs1.blogspot.com/2019/10/of-mice-and-men-crooks-pee-paragraph.html
https://researchpaperwritingservice357.blogspot.com/2019/08/business-strategy-assignment-example.html
https://essayontravelexperience.blogspot.com/2019/04/the-movie-dead-poets-society-essay.html
https://freetermpapers838.blogspot.com/2019/10/desires-for-freedom-essays-research.html
https://essayhelponline12.blogspot.com/2019/07/aaaan-american-indian-wildernessaaa-by.html
https://janeschafferwritingformat.blogspot.com/2019/09/educatioculture-geography-of-childhood.html
https://fiveparagraphessay534.blogspot.com/2019/06/platonic-paradox-essays-research-papers.html
https://finewritingpaperstationery1.blogspot.com/2019/07/airasia-xs-business-environment-tourism.html
https://cheapgoodargumentativeessaytopics.blogspot.com/2019/08/revisiting-eclectic-theory-of-choice-of.html
https://writemycollegepaper123.blogspot.com/2019/06/marketing-research-assignment-example.html
https://criticalessaywriting928.blogspot.com/2019/09/four-seasons-hotels-essay.html
https://havingtroublewritinganessay601.blogspot.com/2019/07/horticultural-machineries-essay.html
https://generalessaysinenglish961.blogspot.com/2019/09/the-jacksonian-era-essay-american.html
https://paytowriteessay97.blogspot.com/2019/06/analysis-of-film-11th-hour-essay.html
","108.162.229.141","20 December, 2019","2019-12-20 15:34:43","N");


--
-- Tabel structure for table `country`
--
DROP TABLE  IF EXISTS `country`;
CREATE TABLE `country` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `country_name` varchar(255) DEFAULT NULL,
  `icon` varchar(256) NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8;

INSERT INTO `country`  VALUES ( "1","Afghanistan","","Y");
INSERT INTO `country`  VALUES ( "2","Albania","","Y");
INSERT INTO `country`  VALUES ( "3","Algeria","","Y");
INSERT INTO `country`  VALUES ( "4","Andorra","","Y");
INSERT INTO `country`  VALUES ( "5","American Samoa","","Y");
INSERT INTO `country`  VALUES ( "6","Angola","","Y");
INSERT INTO `country`  VALUES ( "7","Anguilla","","Y");
INSERT INTO `country`  VALUES ( "8","Antartica","","Y");
INSERT INTO `country`  VALUES ( "9","Antigua and Barbuda","","Y");
INSERT INTO `country`  VALUES ( "10","Argentina","","Y");
INSERT INTO `country`  VALUES ( "11","Armenia","","Y");
INSERT INTO `country`  VALUES ( "12","Aruba","","Y");
INSERT INTO `country`  VALUES ( "13","Ashmore and Cartier Island","","Y");
INSERT INTO `country`  VALUES ( "14","Australia","","N");
INSERT INTO `country`  VALUES ( "15","Austria","","Y");
INSERT INTO `country`  VALUES ( "16","Azerbaijan","","Y");
INSERT INTO `country`  VALUES ( "17","Bahamas","","Y");
INSERT INTO `country`  VALUES ( "18","Bahrain","","Y");
INSERT INTO `country`  VALUES ( "19","Bangladesh","","Y");
INSERT INTO `country`  VALUES ( "20","Barbados","","Y");
INSERT INTO `country`  VALUES ( "21","Belarus","","Y");
INSERT INTO `country`  VALUES ( "22","Belgium","","Y");
INSERT INTO `country`  VALUES ( "23","Belize","","Y");
INSERT INTO `country`  VALUES ( "24","Benin","","Y");
INSERT INTO `country`  VALUES ( "25","Bermuda","","Y");
INSERT INTO `country`  VALUES ( "26","Bhutan","","Y");
INSERT INTO `country`  VALUES ( "27","Bolivia","","Y");
INSERT INTO `country`  VALUES ( "28","Bosnia and Herzegovina","","Y");
INSERT INTO `country`  VALUES ( "29","Botswana","","Y");
INSERT INTO `country`  VALUES ( "30","Brazil","","Y");
INSERT INTO `country`  VALUES ( "31","British Virgin Islands","","Y");
INSERT INTO `country`  VALUES ( "32","Brunei","","Y");
INSERT INTO `country`  VALUES ( "33","Bulgaria","","Y");
INSERT INTO `country`  VALUES ( "34","Burkina Faso","","Y");
INSERT INTO `country`  VALUES ( "35","Burma","","Y");
INSERT INTO `country`  VALUES ( "36","Burundi","","Y");
INSERT INTO `country`  VALUES ( "37","Cambodia","","Y");
INSERT INTO `country`  VALUES ( "38","Cameroon","","Y");
INSERT INTO `country`  VALUES ( "39","Canada","","N");
INSERT INTO `country`  VALUES ( "40","Cape Verde","","Y");
INSERT INTO `country`  VALUES ( "41","Cayman Islands","","Y");
INSERT INTO `country`  VALUES ( "42","Central African Republic","","Y");
INSERT INTO `country`  VALUES ( "43","Chad","","Y");
INSERT INTO `country`  VALUES ( "44","Chile","","Y");
INSERT INTO `country`  VALUES ( "45","China","","Y");
INSERT INTO `country`  VALUES ( "46","Christmas Island","","Y");
INSERT INTO `country`  VALUES ( "47","Clipperton Island","","Y");
INSERT INTO `country`  VALUES ( "48","Cocos (Keeling) Islands","","Y");
INSERT INTO `country`  VALUES ( "49","Colombia","","Y");
INSERT INTO `country`  VALUES ( "50","Comoros","","Y");
INSERT INTO `country`  VALUES ( "51","Congo","","Y");
INSERT INTO `country`  VALUES ( "52","Cook Islands","","Y");
INSERT INTO `country`  VALUES ( "53","Costa Rica","","Y");
INSERT INTO `country`  VALUES ( "54","Cote dIvoire","","Y");
INSERT INTO `country`  VALUES ( "55","Croatia","","Y");
INSERT INTO `country`  VALUES ( "56","Cuba","","Y");
INSERT INTO `country`  VALUES ( "57","Cyprus","","Y");
INSERT INTO `country`  VALUES ( "58","Czeck Republic","","Y");
INSERT INTO `country`  VALUES ( "59","Denmark","","Y");
INSERT INTO `country`  VALUES ( "60","Djibouti","","Y");
INSERT INTO `country`  VALUES ( "61","Dominica","","Y");
INSERT INTO `country`  VALUES ( "62","Dominican Republic","","Y");
INSERT INTO `country`  VALUES ( "63","Ecuador","","Y");
INSERT INTO `country`  VALUES ( "64","Egypt","","Y");
INSERT INTO `country`  VALUES ( "65","El Salvador","","Y");
INSERT INTO `country`  VALUES ( "66","Equatorial Guinea","","Y");
INSERT INTO `country`  VALUES ( "67","Eritrea","","Y");
INSERT INTO `country`  VALUES ( "68","Estonia","","Y");
INSERT INTO `country`  VALUES ( "69","Ethiopia","","Y");
INSERT INTO `country`  VALUES ( "70","Europa Island","","Y");
INSERT INTO `country`  VALUES ( "71","Falkland Islands (Islas Malvinas)","","Y");
INSERT INTO `country`  VALUES ( "72","Faroe Islands","","Y");
INSERT INTO `country`  VALUES ( "73","Fiji","","Y");
INSERT INTO `country`  VALUES ( "74","Finland","","Y");
INSERT INTO `country`  VALUES ( "75","France","","Y");
INSERT INTO `country`  VALUES ( "76","French Guiana","","Y");
INSERT INTO `country`  VALUES ( "77","French Polynesia","","Y");
INSERT INTO `country`  VALUES ( "78","French Southern and Antarctic Lands","","Y");
INSERT INTO `country`  VALUES ( "79","Gabon","","Y");
INSERT INTO `country`  VALUES ( "80","Gambia","","Y");
INSERT INTO `country`  VALUES ( "81","Gaza Strip","","Y");
INSERT INTO `country`  VALUES ( "82","Georgia","","Y");
INSERT INTO `country`  VALUES ( "83","Germany","","Y");
INSERT INTO `country`  VALUES ( "84","Ghana","","Y");
INSERT INTO `country`  VALUES ( "85","Gibraltar","","Y");
INSERT INTO `country`  VALUES ( "86","Glorioso Islands","","Y");
INSERT INTO `country`  VALUES ( "87","Greece","","Y");
INSERT INTO `country`  VALUES ( "88","Greenland","","Y");
INSERT INTO `country`  VALUES ( "89","Grenada","","Y");
INSERT INTO `country`  VALUES ( "90","Guadeloupe","","Y");
INSERT INTO `country`  VALUES ( "91","Guam","","Y");
INSERT INTO `country`  VALUES ( "92","Guatemala","","Y");
INSERT INTO `country`  VALUES ( "93","Guernsey","","Y");
INSERT INTO `country`  VALUES ( "94","Guinea","","Y");
INSERT INTO `country`  VALUES ( "95","Guinea-Bissau","","Y");
INSERT INTO `country`  VALUES ( "96","Guyana","","Y");
INSERT INTO `country`  VALUES ( "97","Haiti","","Y");
INSERT INTO `country`  VALUES ( "98","Heard Island and McDonald Islands","","Y");
INSERT INTO `country`  VALUES ( "99","Holy See (Vatican City)","","Y");
INSERT INTO `country`  VALUES ( "100","Honduras","","Y");
INSERT INTO `country`  VALUES ( "101","Hong Kong","","Y");
INSERT INTO `country`  VALUES ( "102","Howland Island","","Y");
INSERT INTO `country`  VALUES ( "103","Hungary","","Y");
INSERT INTO `country`  VALUES ( "104","Iceland","","Y");
INSERT INTO `country`  VALUES ( "105","India","https://www.countryflags.io/in/shiny/64.png","N");
INSERT INTO `country`  VALUES ( "106","Indonesia","","Y");
INSERT INTO `country`  VALUES ( "107","Iran","","Y");
INSERT INTO `country`  VALUES ( "108","Iraq","","Y");
INSERT INTO `country`  VALUES ( "109","Ireland","","Y");
INSERT INTO `country`  VALUES ( "110","Israel","","Y");
INSERT INTO `country`  VALUES ( "111","Italy","","Y");
INSERT INTO `country`  VALUES ( "112","Jamaica","","Y");
INSERT INTO `country`  VALUES ( "113","Jan Mayen","","Y");
INSERT INTO `country`  VALUES ( "114","Japan","","Y");
INSERT INTO `country`  VALUES ( "115","Jarvis Island","","Y");
INSERT INTO `country`  VALUES ( "116","Jersey","","Y");
INSERT INTO `country`  VALUES ( "117","Johnston Atoll","","Y");
INSERT INTO `country`  VALUES ( "118","Jordan","","Y");
INSERT INTO `country`  VALUES ( "119","Juan de Nova Island","","Y");
INSERT INTO `country`  VALUES ( "120","Kazakhstan","","Y");
INSERT INTO `country`  VALUES ( "121","Kenya","","Y");
INSERT INTO `country`  VALUES ( "122","Kiribati","","Y");
INSERT INTO `country`  VALUES ( "123","Korea North","","Y");
INSERT INTO `country`  VALUES ( "124","Korea South","","Y");
INSERT INTO `country`  VALUES ( "125","Kuwait","","Y");
INSERT INTO `country`  VALUES ( "126","Kyrgyzstan","","Y");
INSERT INTO `country`  VALUES ( "127","Laos","","Y");
INSERT INTO `country`  VALUES ( "128","Latvia","","Y");
INSERT INTO `country`  VALUES ( "129","Lebanon","","Y");
INSERT INTO `country`  VALUES ( "130","Lesotho","","Y");
INSERT INTO `country`  VALUES ( "131","Liberia","","Y");
INSERT INTO `country`  VALUES ( "132","Libya","","Y");
INSERT INTO `country`  VALUES ( "133","Liechtenstein","","Y");
INSERT INTO `country`  VALUES ( "134","Lithuania","","Y");
INSERT INTO `country`  VALUES ( "135","Luxembourg","","Y");
INSERT INTO `country`  VALUES ( "136","Macau","","Y");
INSERT INTO `country`  VALUES ( "137","Macedonia","","Y");
INSERT INTO `country`  VALUES ( "138","Madagascar","","Y");
INSERT INTO `country`  VALUES ( "139","Malawi","","Y");
INSERT INTO `country`  VALUES ( "140","Malaysia","","Y");
INSERT INTO `country`  VALUES ( "141","Maldives","","Y");
INSERT INTO `country`  VALUES ( "142","Mali","","Y");
INSERT INTO `country`  VALUES ( "143","Malta","","Y");
INSERT INTO `country`  VALUES ( "144","Man Isle of","","Y");
INSERT INTO `country`  VALUES ( "145","Marshall Islands","","Y");
INSERT INTO `country`  VALUES ( "146","Martinique","","Y");
INSERT INTO `country`  VALUES ( "147","Mauritania","","Y");
INSERT INTO `country`  VALUES ( "148","Mauritius","","Y");
INSERT INTO `country`  VALUES ( "149","Mayotte","","Y");
INSERT INTO `country`  VALUES ( "150","Mexico","","Y");
INSERT INTO `country`  VALUES ( "151","Micronesia","","Y");
INSERT INTO `country`  VALUES ( "152","Midway Islands","","Y");
INSERT INTO `country`  VALUES ( "153","Moldova","","Y");
INSERT INTO `country`  VALUES ( "154","Monaco","","Y");
INSERT INTO `country`  VALUES ( "155","Mongolia","","Y");
INSERT INTO `country`  VALUES ( "156","Montserrat","","Y");
INSERT INTO `country`  VALUES ( "157","Morocco","","Y");
INSERT INTO `country`  VALUES ( "158","Mozambique","","Y");
INSERT INTO `country`  VALUES ( "159","Namibia","","Y");
INSERT INTO `country`  VALUES ( "160","Nauru","","Y");
INSERT INTO `country`  VALUES ( "161","Nepal","","Y");
INSERT INTO `country`  VALUES ( "162","Netherlands","","Y");
INSERT INTO `country`  VALUES ( "163","Netherlands Antilles","","Y");
INSERT INTO `country`  VALUES ( "164","New Caledonia","","Y");
INSERT INTO `country`  VALUES ( "165","New Zealand","","Y");
INSERT INTO `country`  VALUES ( "166","Nicaragua","","Y");
INSERT INTO `country`  VALUES ( "167","Niger","","Y");
INSERT INTO `country`  VALUES ( "168","Nigeria","https://www.countryflags.io/ng/shiny/64.png","Y");
INSERT INTO `country`  VALUES ( "169","Niue","","Y");
INSERT INTO `country`  VALUES ( "170","Norfolk Island","","Y");
INSERT INTO `country`  VALUES ( "171","No Man`s Island","","Y");
INSERT INTO `country`  VALUES ( "172","Northern Mariana Islands","","Y");
INSERT INTO `country`  VALUES ( "173","Norway","","Y");
INSERT INTO `country`  VALUES ( "174","Oman","","Y");
INSERT INTO `country`  VALUES ( "175","Pakistan","https://www.countryflags.io/pk/shiny/64.png","Y");
INSERT INTO `country`  VALUES ( "176","Palau","","Y");
INSERT INTO `country`  VALUES ( "177","Panama","","Y");
INSERT INTO `country`  VALUES ( "178","Papua New Guinea","","Y");
INSERT INTO `country`  VALUES ( "179","Paraguay","","Y");
INSERT INTO `country`  VALUES ( "180","Peru","","Y");
INSERT INTO `country`  VALUES ( "181","Philippines","","Y");
INSERT INTO `country`  VALUES ( "182","Pitcaim Islands","","Y");
INSERT INTO `country`  VALUES ( "183","Poland","","Y");
INSERT INTO `country`  VALUES ( "184","Portugal","","Y");
INSERT INTO `country`  VALUES ( "185","Puerto Rico","","Y");
INSERT INTO `country`  VALUES ( "186","Qatar","","Y");
INSERT INTO `country`  VALUES ( "187","Reunion","","Y");
INSERT INTO `country`  VALUES ( "188","Romainia","","Y");
INSERT INTO `country`  VALUES ( "189","Russia","","Y");
INSERT INTO `country`  VALUES ( "190","Rwanda","","Y");
INSERT INTO `country`  VALUES ( "191","Saint Helena","","Y");
INSERT INTO `country`  VALUES ( "192","Saint Kitts and Nevis","","Y");
INSERT INTO `country`  VALUES ( "193","Saint Lucia","","Y");
INSERT INTO `country`  VALUES ( "194","Saint Pierre and Miquelon","","Y");
INSERT INTO `country`  VALUES ( "195","Saint Vincent and the Grenadines","","Y");
INSERT INTO `country`  VALUES ( "196","Samoa","","Y");
INSERT INTO `country`  VALUES ( "197","San Marino","","Y");
INSERT INTO `country`  VALUES ( "198","Sao Tome and Principe","","Y");
INSERT INTO `country`  VALUES ( "199","Saudi Arabia","","Y");
INSERT INTO `country`  VALUES ( "200","Scotland","","Y");
INSERT INTO `country`  VALUES ( "201","Senegal","","Y");
INSERT INTO `country`  VALUES ( "202","Serbia and Monterago","","Y");
INSERT INTO `country`  VALUES ( "203","Seychelles","","Y");
INSERT INTO `country`  VALUES ( "204","Sierra Leone","","Y");
INSERT INTO `country`  VALUES ( "205","Singapore","","Y");
INSERT INTO `country`  VALUES ( "206","Slovakia","","Y");
INSERT INTO `country`  VALUES ( "207","Slovenia","","Y");
INSERT INTO `country`  VALUES ( "208","Solomon Islands","","Y");
INSERT INTO `country`  VALUES ( "209","Somalia","","Y");
INSERT INTO `country`  VALUES ( "210","South Africa","","Y");
INSERT INTO `country`  VALUES ( "211","South Georgia and the South Sandwich Islandss","","Y");
INSERT INTO `country`  VALUES ( "212","Spain","","Y");
INSERT INTO `country`  VALUES ( "213","Spratly Islands","","Y");
INSERT INTO `country`  VALUES ( "214","SriLanka","","Y");
INSERT INTO `country`  VALUES ( "215","Sudan","","Y");
INSERT INTO `country`  VALUES ( "216","Suriname","","Y");
INSERT INTO `country`  VALUES ( "217","Svalbard","","Y");
INSERT INTO `country`  VALUES ( "218","Swaziland","","Y");
INSERT INTO `country`  VALUES ( "219","Sweden","","Y");
INSERT INTO `country`  VALUES ( "220","Switzerland","","Y");
INSERT INTO `country`  VALUES ( "221","Syria","","Y");
INSERT INTO `country`  VALUES ( "222","Taiwan","","Y");
INSERT INTO `country`  VALUES ( "223","Tajikistan","","Y");
INSERT INTO `country`  VALUES ( "224","Tanzania","","Y");
INSERT INTO `country`  VALUES ( "225","Thailand","","Y");
INSERT INTO `country`  VALUES ( "226","Trinidad and Tobago","","Y");
INSERT INTO `country`  VALUES ( "227","Toga","","Y");
INSERT INTO `country`  VALUES ( "228","Tokelau","","Y");
INSERT INTO `country`  VALUES ( "229","Tonga","","Y");
INSERT INTO `country`  VALUES ( "230","Tunisia","","Y");
INSERT INTO `country`  VALUES ( "231","Turkey","","Y");
INSERT INTO `country`  VALUES ( "232","Turkmenistan","","Y");
INSERT INTO `country`  VALUES ( "233","Turks and Caicos Island","","Y");
INSERT INTO `country`  VALUES ( "234","Tuvalu","","Y");
INSERT INTO `country`  VALUES ( "235","Uganda","","Y");
INSERT INTO `country`  VALUES ( "236","Ukraine","","Y");
INSERT INTO `country`  VALUES ( "237","United Arab Emirates","","Y");
INSERT INTO `country`  VALUES ( "238","United Kingdom","","N");
INSERT INTO `country`  VALUES ( "239","Uruguay","","Y");
INSERT INTO `country`  VALUES ( "240","United States","","N");
INSERT INTO `country`  VALUES ( "241","Uzbekistan","","Y");
INSERT INTO `country`  VALUES ( "242","Vanuatu","","Y");
INSERT INTO `country`  VALUES ( "243","Venezuela","","Y");
INSERT INTO `country`  VALUES ( "244","Vietnam","","Y");
INSERT INTO `country`  VALUES ( "245","Virgin Islands","","Y");
INSERT INTO `country`  VALUES ( "246","Wales","","Y");
INSERT INTO `country`  VALUES ( "247","Wallis and Futuna","","Y");
INSERT INTO `country`  VALUES ( "248","West Bank","","Y");
INSERT INTO `country`  VALUES ( "249","Western Sahara","","Y");
INSERT INTO `country`  VALUES ( "250","Yemen","","Y");
INSERT INTO `country`  VALUES ( "251","Yugoslavia","","Y");
INSERT INTO `country`  VALUES ( "252","Zambia","","Y");
INSERT INTO `country`  VALUES ( "253","Zimbabwe","","Y");
INSERT INTO `country`  VALUES ( "254","Others","","Y");
INSERT INTO `country`  VALUES ( "255","Doesnt Matter","","Y");


--
-- Tabel structure for table `credits_used`
--
DROP TABLE  IF EXISTS `credits_used`;
CREATE TABLE `credits_used` (
  `used_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `credits_added` int(11) NOT NULL,
  `ipaddress` varchar(50) NOT NULL,
  `datetime` varchar(50) NOT NULL,
  PRIMARY KEY (`used_id`)
) ENGINE=InnoDB AUTO_INCREMENT=375 DEFAULT CHARSET=latin1;

INSERT INTO `credits_used`  VALUES ( "1","74308860","1","8","::1","2019-12-09 09:41:56");
INSERT INTO `credits_used`  VALUES ( "2","73227335","1","15","::1","2019-12-09 09:42:14");
INSERT INTO `credits_used`  VALUES ( "3","73227335","1","15","::1","2019-12-09 09:42:32");
INSERT INTO `credits_used`  VALUES ( "4","74308860","1","8","::1","2019-12-09 09:42:50");
INSERT INTO `credits_used`  VALUES ( "5","32053920","1","15","::1","2019-12-09 09:43:08");
INSERT INTO `credits_used`  VALUES ( "6","32053920","1","15","::1","2019-12-09 09:56:12");
INSERT INTO `credits_used`  VALUES ( "7","32053920","1","15","::1","2019-12-09 09:56:29");
INSERT INTO `credits_used`  VALUES ( "8","32053920","1","15","::1","2019-12-09 09:56:47");
INSERT INTO `credits_used`  VALUES ( "9","32053920","1","15","::1","2019-12-09 09:57:04");
INSERT INTO `credits_used`  VALUES ( "10","32053920","1","15","::1","2019-12-09 09:57:23");
INSERT INTO `credits_used`  VALUES ( "11","32053920","2","15","::1","2019-12-09 10:04:02");
INSERT INTO `credits_used`  VALUES ( "12","32053920","2","15","::1","2019-12-09 10:04:19");
INSERT INTO `credits_used`  VALUES ( "13","32053920","2","15","::1","2019-12-09 10:04:37");
INSERT INTO `credits_used`  VALUES ( "14","32053920","2","15","::1","2019-12-09 10:04:55");
INSERT INTO `credits_used`  VALUES ( "15","74308860","2","8","::1","2019-12-09 10:05:21");
INSERT INTO `credits_used`  VALUES ( "16","32053920","2","15","::1","2019-12-09 10:05:38");
INSERT INTO `credits_used`  VALUES ( "17","73227335","2","15","::1","2019-12-09 10:05:56");
INSERT INTO `credits_used`  VALUES ( "18","73227335","2","15","::1","2019-12-09 10:06:14");
INSERT INTO `credits_used`  VALUES ( "19","32053920","2","15","::1","2019-12-09 10:06:31");
INSERT INTO `credits_used`  VALUES ( "20","32053920","2","15","::1","2019-12-09 10:06:49");
INSERT INTO `credits_used`  VALUES ( "21","74308860","2","8","::1","2019-12-09 10:07:07");
INSERT INTO `credits_used`  VALUES ( "22","32053920","2","15","::1","2019-12-09 10:07:24");
INSERT INTO `credits_used`  VALUES ( "23","73227335","2","15","::1","2019-12-09 10:07:42");
INSERT INTO `credits_used`  VALUES ( "24","32053920","2","15","::1","2019-12-09 10:07:59");
INSERT INTO `credits_used`  VALUES ( "25","73227335","2","15","::1","2019-12-09 10:08:17");
INSERT INTO `credits_used`  VALUES ( "26","32053920","2","15","::1","2019-12-09 10:08:35");
INSERT INTO `credits_used`  VALUES ( "27","73227335","2","15","::1","2019-12-09 10:08:52");
INSERT INTO `credits_used`  VALUES ( "28","32053920","2","15","::1","2019-12-09 10:09:10");
INSERT INTO `credits_used`  VALUES ( "29","74308860","2","8","::1","2019-12-09 10:09:28");
INSERT INTO `credits_used`  VALUES ( "30","74308860","2","8","::1","2019-12-09 10:09:45");
INSERT INTO `credits_used`  VALUES ( "31","32053920","2","15","::1","2019-12-09 10:10:03");
INSERT INTO `credits_used`  VALUES ( "32","73227335","2","15","::1","2019-12-09 10:10:21");
INSERT INTO `credits_used`  VALUES ( "33","73227335","2","15","::1","2019-12-09 10:10:38");
INSERT INTO `credits_used`  VALUES ( "34","74308860","2","8","::1","2019-12-09 10:10:57");
INSERT INTO `credits_used`  VALUES ( "35","32053920","2","15","::1","2019-12-09 10:11:15");
INSERT INTO `credits_used`  VALUES ( "36","74308860","2","8","::1","2019-12-09 10:11:33");
INSERT INTO `credits_used`  VALUES ( "37","32053920","2","15","::1","2019-12-09 10:11:51");
INSERT INTO `credits_used`  VALUES ( "38","73227335","2","15","::1","2019-12-09 10:12:09");
INSERT INTO `credits_used`  VALUES ( "39","97961859","1","5","::1","2019-12-09 10:48:31");
INSERT INTO `credits_used`  VALUES ( "40","35152596","1","5","::1","2019-12-09 10:48:53");
INSERT INTO `credits_used`  VALUES ( "41","34836494","1","5","::1","2019-12-09 10:49:15");
INSERT INTO `credits_used`  VALUES ( "42","18637013","1","5","::1","2019-12-09 10:49:39");
INSERT INTO `credits_used`  VALUES ( "43","35152596","1","5","::1","2019-12-09 10:49:59");
INSERT INTO `credits_used`  VALUES ( "44","34836494","1","5","::1","2019-12-09 10:50:18");
INSERT INTO `credits_used`  VALUES ( "45","18637013","1","5","::1","2019-12-09 10:50:38");
INSERT INTO `credits_used`  VALUES ( "46","35152596","1","5","::1","2019-12-09 10:50:57");
INSERT INTO `credits_used`  VALUES ( "47","35152596","1","5","::1","2019-12-09 10:51:16");
INSERT INTO `credits_used`  VALUES ( "48","34836494","1","5","::1","2019-12-09 10:51:36");
INSERT INTO `credits_used`  VALUES ( "49","95974237","1","5","::1","2019-12-09 10:51:58");
INSERT INTO `credits_used`  VALUES ( "50","35152596","1","5","::1","2019-12-09 10:52:18");
INSERT INTO `credits_used`  VALUES ( "51","97961859","1","5","::1","2019-12-09 10:52:37");
INSERT INTO `credits_used`  VALUES ( "52","34836494","1","5","::1","2019-12-09 10:52:56");
INSERT INTO `credits_used`  VALUES ( "53","18637013","1","5","::1","2019-12-09 10:53:16");
INSERT INTO `credits_used`  VALUES ( "54","97961859","1","5","::1","2019-12-09 10:53:36");
INSERT INTO `credits_used`  VALUES ( "55","97961859","1","5","::1","2019-12-09 10:53:55");
INSERT INTO `credits_used`  VALUES ( "56","35152596","1","5","::1","2019-12-09 10:54:15");
INSERT INTO `credits_used`  VALUES ( "57","18637013","1","5","::1","2019-12-09 10:54:35");
INSERT INTO `credits_used`  VALUES ( "58","35152596","1","5","::1","2019-12-09 10:54:55");
INSERT INTO `credits_used`  VALUES ( "59","18637013","1","5","::1","2019-12-09 10:55:15");
INSERT INTO `credits_used`  VALUES ( "60","97961859","1","5","::1","2019-12-09 10:55:35");
INSERT INTO `credits_used`  VALUES ( "61","18637013","1","5","::1","2019-12-09 10:55:54");
INSERT INTO `credits_used`  VALUES ( "62","34836494","1","5","::1","2019-12-09 10:56:13");
INSERT INTO `credits_used`  VALUES ( "63","95974237","1","5","::1","2019-12-09 10:56:35");
INSERT INTO `credits_used`  VALUES ( "64","95974237","1","5","::1","2019-12-09 10:56:55");
INSERT INTO `credits_used`  VALUES ( "65","34836494","1","5","::1","2019-12-09 10:57:14");
INSERT INTO `credits_used`  VALUES ( "66","97961859","1","5","::1","2019-12-09 10:57:33");
INSERT INTO `credits_used`  VALUES ( "67","35152596","1","5","::1","2019-12-09 10:57:53");
INSERT INTO `credits_used`  VALUES ( "68","35152596","1","5","::1","2019-12-09 10:58:12");
INSERT INTO `credits_used`  VALUES ( "69","95974237","1","5","::1","2019-12-09 10:58:31");
INSERT INTO `credits_used`  VALUES ( "70","97961859","1","5","::1","2019-12-09 10:58:51");
INSERT INTO `credits_used`  VALUES ( "71","34836494","1","5","::1","2019-12-09 10:59:11");
INSERT INTO `credits_used`  VALUES ( "72","95974237","1","5","::1","2019-12-09 10:59:31");
INSERT INTO `credits_used`  VALUES ( "73","97961859","1","5","::1","2019-12-09 10:59:50");
INSERT INTO `credits_used`  VALUES ( "74","34836494","1","5","::1","2019-12-09 11:00:10");
INSERT INTO `credits_used`  VALUES ( "75","97961859","1","5","::1","2019-12-09 11:00:30");
INSERT INTO `credits_used`  VALUES ( "76","34836494","1","5","::1","2019-12-09 11:00:49");
INSERT INTO `credits_used`  VALUES ( "77","97961859","1","5","::1","2019-12-09 11:01:09");
INSERT INTO `credits_used`  VALUES ( "78","34836494","1","5","::1","2019-12-09 11:01:29");
INSERT INTO `credits_used`  VALUES ( "79","95974237","1","5","::1","2019-12-09 11:01:48");
INSERT INTO `credits_used`  VALUES ( "80","34836494","1","5","::1","2019-12-09 11:02:08");
INSERT INTO `credits_used`  VALUES ( "81","18637013","1","5","::1","2019-12-09 11:02:27");
INSERT INTO `credits_used`  VALUES ( "82","34836494","1","5","::1","2019-12-09 11:02:47");
INSERT INTO `credits_used`  VALUES ( "83","18637013","1","5","::1","2019-12-09 11:03:06");
INSERT INTO `credits_used`  VALUES ( "84","34836494","1","5","::1","2019-12-09 11:03:26");
INSERT INTO `credits_used`  VALUES ( "85","34836494","1","5","::1","2019-12-09 11:03:46");
INSERT INTO `credits_used`  VALUES ( "86","34836494","1","5","::1","2019-12-09 11:04:05");
INSERT INTO `credits_used`  VALUES ( "87","95974237","1","5","::1","2019-12-09 11:04:26");
INSERT INTO `credits_used`  VALUES ( "88","34836494","1","5","::1","2019-12-09 11:04:46");
INSERT INTO `credits_used`  VALUES ( "89","95974237","1","5","::1","2019-12-09 11:05:05");
INSERT INTO `credits_used`  VALUES ( "90","97961859","1","5","::1","2019-12-09 11:05:24");
INSERT INTO `credits_used`  VALUES ( "91","18637013","1","5","::1","2019-12-09 11:05:44");
INSERT INTO `credits_used`  VALUES ( "92","34836494","1","5","::1","2019-12-09 11:06:03");
INSERT INTO `credits_used`  VALUES ( "93","95974237","1","5","::1","2019-12-09 11:06:23");
INSERT INTO `credits_used`  VALUES ( "94","18637013","1","5","::1","2019-12-09 11:06:42");
INSERT INTO `credits_used`  VALUES ( "95","95974237","1","5","::1","2019-12-09 11:07:01");
INSERT INTO `credits_used`  VALUES ( "96","35152596","1","5","::1","2019-12-09 11:07:21");
INSERT INTO `credits_used`  VALUES ( "97","35152596","1","5","::1","2019-12-09 11:07:40");
INSERT INTO `credits_used`  VALUES ( "98","35152596","1","5","::1","2019-12-09 11:08:00");
INSERT INTO `credits_used`  VALUES ( "99","35152596","1","5","::1","2019-12-09 11:08:19");
INSERT INTO `credits_used`  VALUES ( "100","95974237","1","5","::1","2019-12-09 11:08:39");
INSERT INTO `credits_used`  VALUES ( "101","35152596","1","5","::1","2019-12-09 11:08:58");
INSERT INTO `credits_used`  VALUES ( "102","73227335","2","15","202.142.113.82","2019-12-10 09:45:12");
INSERT INTO `credits_used`  VALUES ( "103","32053920","2","15","202.142.113.82","2019-12-10 09:45:32");
INSERT INTO `credits_used`  VALUES ( "104","73227335","2","15","202.142.113.82","2019-12-10 09:45:51");
INSERT INTO `credits_used`  VALUES ( "105","32053920","2","15","202.142.113.82","2019-12-10 09:46:11");
INSERT INTO `credits_used`  VALUES ( "106","74308860","2","8","202.142.113.82","2019-12-10 09:46:31");
INSERT INTO `credits_used`  VALUES ( "107","74308860","2","8","202.142.113.82","2019-12-10 09:46:51");
INSERT INTO `credits_used`  VALUES ( "108","74308860","2","8","202.142.113.82","2019-12-10 09:47:11");
INSERT INTO `credits_used`  VALUES ( "109","32053920","2","15","202.142.113.82","2019-12-10 09:47:31");
INSERT INTO `credits_used`  VALUES ( "110","74308860","2","8","202.142.113.82","2019-12-10 09:47:51");
INSERT INTO `credits_used`  VALUES ( "111","32053920","2","15","202.142.113.82","2019-12-10 09:48:11");
INSERT INTO `credits_used`  VALUES ( "112","74308860","2","8","202.142.113.82","2019-12-10 09:48:32");
INSERT INTO `credits_used`  VALUES ( "113","32053920","2","15","202.142.113.82","2019-12-10 09:48:52");
INSERT INTO `credits_used`  VALUES ( "114","74308860","2","8","202.142.113.82","2019-12-10 09:49:11");
INSERT INTO `credits_used`  VALUES ( "115","74308860","2","8","202.142.113.82","2019-12-10 09:49:32");
INSERT INTO `credits_used`  VALUES ( "116","73227335","2","15","202.142.113.82","2019-12-10 09:50:44");
INSERT INTO `credits_used`  VALUES ( "117","32053920","2","15","202.142.113.82","2019-12-10 09:51:03");
INSERT INTO `credits_used`  VALUES ( "118","73227335","2","15","202.142.113.82","2019-12-10 09:51:22");
INSERT INTO `credits_used`  VALUES ( "119","73227335","2","15","202.142.113.82","2019-12-10 09:51:42");
INSERT INTO `credits_used`  VALUES ( "120","73227335","2","15","202.142.113.82","2019-12-10 09:52:01");
INSERT INTO `credits_used`  VALUES ( "121","32053920","2","15","202.142.113.82","2019-12-10 09:52:20");
INSERT INTO `credits_used`  VALUES ( "122","32053920","2","15","162.158.158.108","2019-12-10 09:52:20");
INSERT INTO `credits_used`  VALUES ( "123","74308860","2","8","202.142.113.82","2019-12-10 09:52:38");
INSERT INTO `credits_used`  VALUES ( "124","73227335","2","15","162.158.159.51","2019-12-10 09:52:40");
INSERT INTO `credits_used`  VALUES ( "125","73227335","0","15","202.142.113.82","2019-12-10 09:52:58");
INSERT INTO `credits_used`  VALUES ( "126","74308860","0","8","162.158.159.89","2019-12-10 09:52:59");
INSERT INTO `credits_used`  VALUES ( "127","74308860","0","8","202.142.113.82","2019-12-10 09:53:17");
INSERT INTO `credits_used`  VALUES ( "128","34836494","0","5","141.101.98.171","2019-12-10 09:53:47");
INSERT INTO `credits_used`  VALUES ( "129","35152596","1","5","202.142.113.82","2019-12-10 09:55:15");
INSERT INTO `credits_used`  VALUES ( "130","35152596","1","5","202.142.113.82","2019-12-10 09:55:37");
INSERT INTO `credits_used`  VALUES ( "131","95974237","1","5","202.142.113.82","2019-12-10 09:55:59");
INSERT INTO `credits_used`  VALUES ( "132","35152596","1","5","202.142.113.82","2019-12-10 09:56:22");
INSERT INTO `credits_used`  VALUES ( "133","95974237","1","5","202.142.113.82","2019-12-10 09:56:44");
INSERT INTO `credits_used`  VALUES ( "134","97961859","1","5","202.142.113.82","2019-12-10 09:57:07");
INSERT INTO `credits_used`  VALUES ( "135","35152596","1","5","141.101.98.171","2019-12-11 05:38:00");
INSERT INTO `credits_used`  VALUES ( "136","97961859","1","5","141.101.98.171","2019-12-11 05:38:41");
INSERT INTO `credits_used`  VALUES ( "137","97961859","1","5","162.158.158.108","2019-12-11 05:39:21");
INSERT INTO `credits_used`  VALUES ( "138","95974237","1","5","162.158.158.108","2019-12-11 05:40:01");
INSERT INTO `credits_used`  VALUES ( "139","34836494","1","5","162.158.158.108","2019-12-11 05:40:41");
INSERT INTO `credits_used`  VALUES ( "140","97961859","1","5","162.158.158.108","2019-12-11 05:41:21");
INSERT INTO `credits_used`  VALUES ( "141","97961859","1","5","162.158.158.108","2019-12-11 05:42:01");
INSERT INTO `credits_used`  VALUES ( "142","35152596","1","5","162.158.158.108","2019-12-11 05:42:42");
INSERT INTO `credits_used`  VALUES ( "143","73227335","2","15","172.69.135.237","2019-12-11 11:17:44");
INSERT INTO `credits_used`  VALUES ( "144","74308860","2","8","172.69.135.211","2019-12-11 12:43:11");
INSERT INTO `credits_used`  VALUES ( "145","73227335","2","15","172.69.135.211","2019-12-11 12:48:22");
INSERT INTO `credits_used`  VALUES ( "146","74308860","2","8","172.69.135.211","2019-12-11 12:50:27");
INSERT INTO `credits_used`  VALUES ( "147","74308860","2","8","172.69.135.211","2019-12-11 12:50:47");
INSERT INTO `credits_used`  VALUES ( "148","74308860","2","8","172.69.135.211","2019-12-11 12:51:07");
INSERT INTO `credits_used`  VALUES ( "149","97961859","1","7","162.158.167.13","2019-12-11 23:02:55");
INSERT INTO `credits_used`  VALUES ( "150","74308860","2","8","172.69.135.211","2019-12-12 01:41:15");
INSERT INTO `credits_used`  VALUES ( "191","74308860","2","8","172.69.135.211","2019-12-12 01:42:46");
INSERT INTO `credits_used`  VALUES ( "192","73227335","2","15","172.69.135.211","2019-12-12 01:50:04");
INSERT INTO `credits_used`  VALUES ( "193","74308860","2","8","172.69.135.211","2019-12-12 02:00:40");
INSERT INTO `credits_used`  VALUES ( "194","97961859","1","7","141.101.98.171","2019-12-13 06:47:57");
INSERT INTO `credits_used`  VALUES ( "195","97961859","1","7","141.101.98.171","2019-12-13 06:48:20");
INSERT INTO `credits_used`  VALUES ( "196","97961859","1","7","162.158.158.8","2019-12-13 06:48:50");
INSERT INTO `credits_used`  VALUES ( "197","97961859","1","7","162.158.159.51","2019-12-13 06:49:15");
INSERT INTO `credits_used`  VALUES ( "198","97961859","1","7","162.158.159.51","2019-12-13 06:49:39");
INSERT INTO `credits_used`  VALUES ( "199","97961859","1","7","162.158.158.8","2019-12-13 06:50:03");
INSERT INTO `credits_used`  VALUES ( "200","97961859","1","7","141.101.98.171","2019-12-13 06:50:25");
INSERT INTO `credits_used`  VALUES ( "201","97961859","1","7","162.158.158.250","2019-12-13 06:50:52");
INSERT INTO `credits_used`  VALUES ( "202","97961859","1","7","162.158.158.250","2019-12-13 06:50:54");
INSERT INTO `credits_used`  VALUES ( "203","97961859","1","7","141.101.98.171","2019-12-13 06:51:16");
INSERT INTO `credits_used`  VALUES ( "204","97961859","1","7","141.101.98.171","2019-12-13 06:51:20");
INSERT INTO `credits_used`  VALUES ( "205","97961859","1","7","162.158.154.228","2019-12-13 06:51:38");
INSERT INTO `credits_used`  VALUES ( "206","97961859","1","7","162.158.154.228","2019-12-13 06:51:44");
INSERT INTO `credits_used`  VALUES ( "207","97961859","1","7","162.158.159.89","2019-12-13 06:52:05");
INSERT INTO `credits_used`  VALUES ( "208","97961859","1","7","162.158.159.89","2019-12-13 06:52:07");
INSERT INTO `credits_used`  VALUES ( "209","97961859","1","7","141.101.99.148","2019-12-13 06:52:28");
INSERT INTO `credits_used`  VALUES ( "210","97961859","1","7","141.101.99.148","2019-12-13 06:52:29");
INSERT INTO `credits_used`  VALUES ( "211","97961859","1","7","162.158.158.250","2019-12-13 06:52:54");
INSERT INTO `credits_used`  VALUES ( "212","97961859","1","7","162.158.158.250","2019-12-13 06:52:55");
INSERT INTO `credits_used`  VALUES ( "213","97961859","1","7","162.158.159.51","2019-12-13 06:53:20");
INSERT INTO `credits_used`  VALUES ( "214","97961859","1","7","162.158.159.51","2019-12-13 06:53:20");
INSERT INTO `credits_used`  VALUES ( "215","97961859","1","7","141.101.98.171","2019-12-13 06:53:43");
INSERT INTO `credits_used`  VALUES ( "216","97961859","1","7","141.101.98.171","2019-12-13 06:53:45");
INSERT INTO `credits_used`  VALUES ( "217","97961859","1","7","162.158.159.51","2019-12-13 06:54:07");
INSERT INTO `credits_used`  VALUES ( "218","97961859","1","7","162.158.159.51","2019-12-13 06:54:08");
INSERT INTO `credits_used`  VALUES ( "219","97961859","1","7","141.101.98.171","2019-12-13 06:54:32");
INSERT INTO `credits_used`  VALUES ( "220","97961859","1","7","141.101.98.171","2019-12-13 06:54:33");
INSERT INTO `credits_used`  VALUES ( "221","97961859","1","7","162.158.158.250","2019-12-13 06:54:56");
INSERT INTO `credits_used`  VALUES ( "222","97961859","1","7","162.158.158.250","2019-12-13 06:54:58");
INSERT INTO `credits_used`  VALUES ( "223","97961859","1","7","162.158.154.138","2019-12-13 06:55:21");
INSERT INTO `credits_used`  VALUES ( "224","97961859","1","7","162.158.154.138","2019-12-13 06:55:21");
INSERT INTO `credits_used`  VALUES ( "225","97961859","1","7","162.158.158.146","2019-12-13 06:55:44");
INSERT INTO `credits_used`  VALUES ( "226","97961859","1","7","162.158.158.146","2019-12-13 06:55:45");
INSERT INTO `credits_used`  VALUES ( "227","97961859","1","7","141.101.98.171","2019-12-13 06:56:08");
INSERT INTO `credits_used`  VALUES ( "228","97961859","1","7","162.158.154.138","2019-12-13 06:56:19");
INSERT INTO `credits_used`  VALUES ( "229","97961859","1","7","162.158.158.32","2019-12-13 06:56:30");
INSERT INTO `credits_used`  VALUES ( "230","97961859","1","7","162.158.158.108","2019-12-13 06:56:42");
INSERT INTO `credits_used`  VALUES ( "231","97961859","1","7","141.101.98.171","2019-12-13 06:56:53");
INSERT INTO `credits_used`  VALUES ( "232","97961859","1","7","141.101.98.171","2019-12-13 06:57:06");
INSERT INTO `credits_used`  VALUES ( "233","97961859","1","7","141.101.98.171","2019-12-13 06:57:16");
INSERT INTO `credits_used`  VALUES ( "234","97961859","1","7","162.158.155.85","2019-12-13 06:57:30");
INSERT INTO `credits_used`  VALUES ( "235","97961859","1","7","162.158.158.8","2019-12-13 06:57:40");
INSERT INTO `credits_used`  VALUES ( "236","97961859","1","7","162.158.158.8","2019-12-13 06:57:55");
INSERT INTO `credits_used`  VALUES ( "237","97961859","1","7","162.158.158.8","2019-12-13 06:58:04");
INSERT INTO `credits_used`  VALUES ( "238","97961859","1","7","162.158.159.51","2019-12-13 06:58:16");
INSERT INTO `credits_used`  VALUES ( "239","97961859","1","7","162.158.154.138","2019-12-13 06:58:27");
INSERT INTO `credits_used`  VALUES ( "240","97961859","1","7","162.158.159.89","2019-12-13 06:58:40");
INSERT INTO `credits_used`  VALUES ( "241","97961859","1","7","162.158.158.108","2019-12-13 06:58:50");
INSERT INTO `credits_used`  VALUES ( "242","97961859","1","7","141.101.98.171","2019-12-13 06:59:05");
INSERT INTO `credits_used`  VALUES ( "243","97961859","1","7","162.158.158.146","2019-12-13 06:59:14");
INSERT INTO `credits_used`  VALUES ( "244","97961859","1","7","141.101.98.171","2019-12-13 06:59:29");
INSERT INTO `credits_used`  VALUES ( "245","97961859","1","7","162.158.158.108","2019-12-13 06:59:39");
INSERT INTO `credits_used`  VALUES ( "246","97961859","1","7","162.158.159.89","2019-12-13 06:59:51");
INSERT INTO `credits_used`  VALUES ( "247","97961859","1","7","162.158.159.89","2019-12-13 07:00:04");
INSERT INTO `credits_used`  VALUES ( "248","97961859","1","7","162.158.154.228","2019-12-13 07:00:18");
INSERT INTO `credits_used`  VALUES ( "249","97961859","1","7","162.158.155.85","2019-12-13 07:00:28");
INSERT INTO `credits_used`  VALUES ( "250","97961859","1","7","162.158.158.146","2019-12-13 07:00:43");
INSERT INTO `credits_used`  VALUES ( "251","97961859","1","7","162.158.154.228","2019-12-13 07:01:00");
INSERT INTO `credits_used`  VALUES ( "252","97961859","1","7","162.158.155.85","2019-12-13 07:01:09");
INSERT INTO `credits_used`  VALUES ( "253","97961859","1","7","162.158.154.138","2019-12-13 07:01:26");
INSERT INTO `credits_used`  VALUES ( "254","97961859","1","7","162.158.154.138","2019-12-13 07:01:31");
INSERT INTO `credits_used`  VALUES ( "255","97961859","1","7","162.158.158.32","2019-12-13 07:01:53");
INSERT INTO `credits_used`  VALUES ( "256","97961859","1","7","162.158.158.32","2019-12-13 07:01:55");
INSERT INTO `credits_used`  VALUES ( "257","97961859","1","7","162.158.154.228","2019-12-13 07:02:18");
INSERT INTO `credits_used`  VALUES ( "258","97961859","1","7","162.158.154.228","2019-12-13 07:02:19");
INSERT INTO `credits_used`  VALUES ( "259","97961859","1","7","162.158.154.186","2019-12-13 07:02:47");
INSERT INTO `credits_used`  VALUES ( "260","97961859","1","7","162.158.154.186","2019-12-13 07:02:47");
INSERT INTO `credits_used`  VALUES ( "261","97961859","1","7","162.158.158.108","2019-12-13 07:03:13");
INSERT INTO `credits_used`  VALUES ( "262","97961859","1","7","162.158.158.108","2019-12-13 07:03:13");
INSERT INTO `credits_used`  VALUES ( "263","97961859","1","7","162.158.158.146","2019-12-13 07:03:39");
INSERT INTO `credits_used`  VALUES ( "264","97961859","1","7","162.158.158.146","2019-12-13 07:03:41");
INSERT INTO `credits_used`  VALUES ( "265","97961859","1","7","141.101.98.171","2019-12-13 07:04:07");
INSERT INTO `credits_used`  VALUES ( "266","97961859","1","7","162.158.155.115","2019-12-13 07:04:18");
INSERT INTO `credits_used`  VALUES ( "267","97961859","1","7","141.101.98.171","2019-12-13 07:04:32");
INSERT INTO `credits_used`  VALUES ( "268","97961859","1","7","141.101.98.171","2019-12-13 07:04:43");
INSERT INTO `credits_used`  VALUES ( "269","97961859","1","7","162.158.158.32","2019-12-13 07:04:54");
INSERT INTO `credits_used`  VALUES ( "270","97961859","1","7","141.101.98.171","2019-12-13 07:05:07");
INSERT INTO `credits_used`  VALUES ( "271","97961859","1","7","141.101.98.171","2019-12-13 07:05:25");
INSERT INTO `credits_used`  VALUES ( "272","97961859","1","7","162.158.158.32","2019-12-13 07:05:30");
INSERT INTO `credits_used`  VALUES ( "273","97961859","1","7","162.158.154.228","2019-12-13 07:05:49");
INSERT INTO `credits_used`  VALUES ( "274","97961859","1","7","162.158.154.228","2019-12-13 07:05:54");
INSERT INTO `credits_used`  VALUES ( "275","97961859","1","7","162.158.159.87","2019-12-13 07:06:11");
INSERT INTO `credits_used`  VALUES ( "276","97961859","1","7","162.158.158.108","2019-12-13 07:06:23");
INSERT INTO `credits_used`  VALUES ( "277","97961859","1","7","162.158.158.8","2019-12-13 07:06:33");
INSERT INTO `credits_used`  VALUES ( "278","97961859","1","7","162.158.158.108","2019-12-13 07:06:46");
INSERT INTO `credits_used`  VALUES ( "279","97961859","1","7","162.158.158.108","2019-12-13 07:06:55");
INSERT INTO `credits_used`  VALUES ( "280","97961859","1","7","162.158.155.115","2019-12-13 07:07:09");
INSERT INTO `credits_used`  VALUES ( "281","97961859","1","7","162.158.159.87","2019-12-13 07:07:18");
INSERT INTO `credits_used`  VALUES ( "282","97961859","1","7","162.158.155.85","2019-12-13 07:07:31");
INSERT INTO `credits_used`  VALUES ( "283","97961859","1","7","162.158.158.108","2019-12-13 07:07:40");
INSERT INTO `credits_used`  VALUES ( "284","97961859","1","7","162.158.154.228","2019-12-13 07:07:54");
INSERT INTO `credits_used`  VALUES ( "285","97961859","1","7","162.158.154.228","2019-12-13 07:08:03");
INSERT INTO `credits_used`  VALUES ( "286","97961859","1","7","141.101.98.171","2019-12-13 07:08:18");
INSERT INTO `credits_used`  VALUES ( "287","97961859","1","7","141.101.98.171","2019-12-13 07:08:24");
INSERT INTO `credits_used`  VALUES ( "288","97961859","1","7","141.101.98.171","2019-12-13 07:08:41");
INSERT INTO `credits_used`  VALUES ( "289","97961859","1","7","162.158.154.228","2019-12-13 07:08:48");
INSERT INTO `credits_used`  VALUES ( "290","97961859","1","7","141.101.98.171","2019-12-13 07:09:03");
INSERT INTO `credits_used`  VALUES ( "291","97961859","1","7","162.158.158.108","2019-12-13 07:09:12");
INSERT INTO `credits_used`  VALUES ( "292","97961859","1","7","162.158.159.51","2019-12-13 07:09:29");
INSERT INTO `credits_used`  VALUES ( "293","97961859","1","7","162.158.159.51","2019-12-13 07:09:34");
INSERT INTO `credits_used`  VALUES ( "294","97961859","1","7","162.158.158.250","2019-12-13 07:09:53");
INSERT INTO `credits_used`  VALUES ( "295","97961859","1","7","162.158.158.250","2019-12-13 07:09:56");
INSERT INTO `credits_used`  VALUES ( "296","97961859","1","7","162.158.158.8","2019-12-13 07:10:18");
INSERT INTO `credits_used`  VALUES ( "297","97961859","1","7","162.158.158.8","2019-12-13 07:10:19");
INSERT INTO `credits_used`  VALUES ( "298","97961859","1","7","162.158.158.108","2019-12-13 07:10:40");
INSERT INTO `credits_used`  VALUES ( "299","97961859","1","7","162.158.158.108","2019-12-13 07:10:41");
INSERT INTO `credits_used`  VALUES ( "300","97961859","1","7","141.101.99.148","2019-12-13 07:11:03");
INSERT INTO `credits_used`  VALUES ( "301","97961859","1","7","141.101.99.148","2019-12-13 07:11:07");
INSERT INTO `credits_used`  VALUES ( "302","97961859","1","7","162.158.159.51","2019-12-13 07:11:27");
INSERT INTO `credits_used`  VALUES ( "303","97961859","1","7","162.158.159.51","2019-12-13 07:11:30");
INSERT INTO `credits_used`  VALUES ( "304","97961859","1","7","162.158.154.186","2019-12-13 07:11:51");
INSERT INTO `credits_used`  VALUES ( "305","97961859","1","7","162.158.158.108","2019-12-13 07:11:58");
INSERT INTO `credits_used`  VALUES ( "306","97961859","1","7","162.158.155.115","2019-12-13 07:12:14");
INSERT INTO `credits_used`  VALUES ( "307","97961859","1","7","162.158.158.250","2019-12-13 07:12:28");
INSERT INTO `credits_used`  VALUES ( "308","97961859","1","7","141.101.98.171","2019-12-13 07:12:52");
INSERT INTO `credits_used`  VALUES ( "309","97961859","1","7","141.101.98.171","2019-12-13 07:12:53");
INSERT INTO `credits_used`  VALUES ( "310","97961859","1","7","162.158.154.138","2019-12-13 07:13:16");
INSERT INTO `credits_used`  VALUES ( "311","97961859","1","7","141.101.98.171","2019-12-13 07:13:18");
INSERT INTO `credits_used`  VALUES ( "312","97961859","1","7","141.101.99.148","2019-12-13 07:14:20");
INSERT INTO `credits_used`  VALUES ( "313","97961859","1","7","141.101.99.148","2019-12-13 07:14:25");
INSERT INTO `credits_used`  VALUES ( "314","97961859","1","7","162.158.158.250","2019-12-13 07:14:44");
INSERT INTO `credits_used`  VALUES ( "315","97961859","1","7","162.158.155.115","2019-12-13 07:14:48");
INSERT INTO `credits_used`  VALUES ( "316","97961859","1","7","162.158.154.138","2019-12-13 07:15:06");
INSERT INTO `credits_used`  VALUES ( "317","97961859","1","7","162.158.154.138","2019-12-13 07:15:10");
INSERT INTO `credits_used`  VALUES ( "318","97961859","1","7","162.158.154.138","2019-12-13 07:15:28");
INSERT INTO `credits_used`  VALUES ( "319","97961859","1","7","162.158.154.138","2019-12-13 07:15:36");
INSERT INTO `credits_used`  VALUES ( "320","97961859","1","7","162.158.154.186","2019-12-13 07:15:51");
INSERT INTO `credits_used`  VALUES ( "321","97961859","1","7","162.158.159.87","2019-12-13 07:16:05");
INSERT INTO `credits_used`  VALUES ( "322","97961859","1","7","162.158.155.85","2019-12-13 07:16:12");
INSERT INTO `credits_used`  VALUES ( "323","97961859","1","7","162.158.158.8","2019-12-13 07:16:29");
INSERT INTO `credits_used`  VALUES ( "324","97961859","1","7","162.158.158.8","2019-12-13 07:16:33");
INSERT INTO `credits_used`  VALUES ( "325","97961859","1","7","162.158.154.228","2019-12-13 07:16:51");
INSERT INTO `credits_used`  VALUES ( "326","97961859","1","7","162.158.154.228","2019-12-13 07:16:56");
INSERT INTO `credits_used`  VALUES ( "327","97961859","1","7","162.158.154.228","2019-12-13 07:17:14");
INSERT INTO `credits_used`  VALUES ( "328","97961859","1","7","162.158.155.115","2019-12-13 07:17:19");
INSERT INTO `credits_used`  VALUES ( "329","97961859","1","7","162.158.158.250","2019-12-13 07:17:45");
INSERT INTO `credits_used`  VALUES ( "330","97961859","1","7","162.158.158.250","2019-12-13 07:17:46");
INSERT INTO `credits_used`  VALUES ( "331","97961859","1","7","162.158.158.250","2019-12-13 07:18:15");
INSERT INTO `credits_used`  VALUES ( "332","97961859","1","7","162.158.158.250","2019-12-13 07:18:15");
INSERT INTO `credits_used`  VALUES ( "333","97961859","1","7","162.158.158.146","2019-12-13 07:18:38");
INSERT INTO `credits_used`  VALUES ( "334","97961859","1","7","162.158.158.146","2019-12-13 07:18:39");
INSERT INTO `credits_used`  VALUES ( "335","97961859","1","7","162.158.158.108","2019-12-13 07:19:12");
INSERT INTO `credits_used`  VALUES ( "336","97961859","1","7","162.158.158.108","2019-12-13 07:19:13");
INSERT INTO `credits_used`  VALUES ( "337","97961859","1","7","162.158.158.32","2019-12-13 07:20:09");
INSERT INTO `credits_used`  VALUES ( "338","97961859","1","7","162.158.158.32","2019-12-13 07:20:10");
INSERT INTO `credits_used`  VALUES ( "339","97961859","1","7","162.158.159.51","2019-12-13 07:20:34");
INSERT INTO `credits_used`  VALUES ( "340","97961859","1","7","162.158.159.87","2019-12-13 07:20:58");
INSERT INTO `credits_used`  VALUES ( "341","97961859","1","7","162.158.158.146","2019-12-13 07:21:20");
INSERT INTO `credits_used`  VALUES ( "342","97961859","1","7","162.158.158.146","2019-12-13 07:21:23");
INSERT INTO `credits_used`  VALUES ( "343","97961859","1","7","162.158.159.89","2019-12-13 07:21:43");
INSERT INTO `credits_used`  VALUES ( "344","97961859","1","7","162.158.159.89","2019-12-13 07:21:46");
INSERT INTO `credits_used`  VALUES ( "345","97961859","1","7","162.158.155.85","2019-12-13 07:22:07");
INSERT INTO `credits_used`  VALUES ( "346","35152596","2","5","162.158.155.115","2019-12-19 03:12:46");
INSERT INTO `credits_used`  VALUES ( "347","35152596","2","5","162.158.155.115","2019-12-19 03:13:35");
INSERT INTO `credits_used`  VALUES ( "348","34836494","2","5","162.158.155.115","2019-12-19 03:14:23");
INSERT INTO `credits_used`  VALUES ( "349","35152596","2","5","162.158.155.115","2019-12-19 03:15:02");
INSERT INTO `credits_used`  VALUES ( "350","34836494","2","5","162.158.155.115","2019-12-19 03:15:23");
INSERT INTO `credits_used`  VALUES ( "351","35152596","2","5","162.158.155.115","2019-12-19 03:15:44");
INSERT INTO `credits_used`  VALUES ( "352","35152596","2","5","162.158.155.115","2019-12-19 03:16:04");
INSERT INTO `credits_used`  VALUES ( "353","35152596","2","5","162.158.155.115","2019-12-19 03:16:25");
INSERT INTO `credits_used`  VALUES ( "354","34836494","2","5","162.158.155.115","2019-12-19 03:16:53");
INSERT INTO `credits_used`  VALUES ( "355","18637013","2","5","162.158.155.115","2019-12-19 03:17:12");
INSERT INTO `credits_used`  VALUES ( "356","34836494","2","5","162.158.155.115","2019-12-19 03:17:33");
INSERT INTO `credits_used`  VALUES ( "357","34836494","2","5","162.158.155.115","2019-12-19 03:17:48");
INSERT INTO `credits_used`  VALUES ( "358","35152596","2","5","162.158.155.115","2019-12-19 03:18:03");
INSERT INTO `credits_used`  VALUES ( "359","32053920","2","15","162.158.155.115","2019-12-19 03:18:20");
INSERT INTO `credits_used`  VALUES ( "360","32053920","2","15","162.158.155.115","2019-12-19 03:18:37");
INSERT INTO `credits_used`  VALUES ( "361","34836494","2","5","162.158.155.115","2019-12-19 03:18:56");
INSERT INTO `credits_used`  VALUES ( "362","35152596","2","5","162.158.155.115","2019-12-19 03:19:16");
INSERT INTO `credits_used`  VALUES ( "363","70206996","1","6","162.158.158.32","2019-12-22 01:54:00");
INSERT INTO `credits_used`  VALUES ( "364","45308209","1","9","162.158.158.32","2019-12-22 01:54:45");
INSERT INTO `credits_used`  VALUES ( "365","97961859","1","7","162.158.158.32","2019-12-22 01:55:27");
INSERT INTO `credits_used`  VALUES ( "366","97961859","1","7","162.158.158.32","2019-12-22 01:55:47");
INSERT INTO `credits_used`  VALUES ( "367","97961859","1","7","162.158.158.32","2019-12-22 01:56:08");
INSERT INTO `credits_used`  VALUES ( "368","97961859","1","7","162.158.158.32","2019-12-22 01:56:28");
INSERT INTO `credits_used`  VALUES ( "369","97961859","1","7","162.158.158.32","2019-12-22 01:56:48");
INSERT INTO `credits_used`  VALUES ( "370","97961859","1","7","162.158.158.32","2019-12-22 01:57:07");
INSERT INTO `credits_used`  VALUES ( "371","35152596","1","5","162.158.158.32","2019-12-22 01:57:26");
INSERT INTO `credits_used`  VALUES ( "372","97961859","1","7","162.158.158.32","2019-12-22 01:57:46");
INSERT INTO `credits_used`  VALUES ( "373","34836494","1","5","162.158.158.32","2019-12-22 01:58:06");
INSERT INTO `credits_used`  VALUES ( "374","97961859","1","7","162.158.158.32","2019-12-22 01:58:25");


--
-- Tabel structure for table `faq_category`
--
DROP TABLE  IF EXISTS `faq_category`;
CREATE TABLE `faq_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(256) NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `faq_category`  VALUES ( "1","General","Y");
INSERT INTO `faq_category`  VALUES ( "2","Subscription","Y");


--
-- Tabel structure for table `frequent_questions`
--
DROP TABLE  IF EXISTS `frequent_questions`;
CREATE TABLE `frequent_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `faqcat` int(11) NOT NULL,
  `question` varchar(256) NOT NULL,
  `answer` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `frequent_questions`  VALUES ( "1","1","What is Wetroo?","Wetroo is a platform, where we generate leads from different sources and share among potential providers. Providers can choose the lead which they wanted to buy, each lead having a fee which providers needs to pay to buy client info. We share client info immediately and providers can directly contact the client and close the deal.");
INSERT INTO `frequent_questions`  VALUES ( "2","1","Do you guarantee that the leads are good?","We do have a quality guarantee! While we cannot guarantee that every client will turn out to be good, or even end up deciding to go on with their project, we do guarantee certain things. We get leads from different sources and verify the genuinely and then share it in our groups so that potential team and work on it.");
INSERT INTO `frequent_questions`  VALUES ( "3","1","Why should I pay for leads! The person who wants the project done should pay right?","Everyone in business pays for leads, either by advertising, or renting a storefront or marketing on the web.</br></br>

If you are a freelancer or have a design business then you already do pay for leads, either by printing business cards, buying ads, postcards, Pay-per-click ads, the yellow pages, a sign on a business...</br></br>

Its all marketing cost and one way or another if your going to attract potential customers (eg leads) you are going to pay. After you add it all up, you will see the COA (Cost of acquisition) of a client is actually quite low compared with say Google ads, Magazine or Newspaper ads, or other traditional online platforms bidding.</br></br>

Most people build it into the cost of doing business. In other words, you should model your prices to cover the cost of your lead and still make a profit.");
INSERT INTO `frequent_questions`  VALUES ( "4","1","Once I see a project I want, how do I get the contact information?","First you must contact us in private chat. After this you will be able to purchase lead info (We accept payment using PayTM and NEFT only). Once you purchase the lead, the client is notified that you going to contact him/her. You can directly call or mail client and discuss the project requirements.");
INSERT INTO `frequent_questions`  VALUES ( "5","1","How does Wetroo services differ from the other freelance sites?","Unlike other websites such as freelancer, guru, upwork, peopleperhour we do not charge a commission or a percentage for the work that you do. All we do is offer the lead and give you an opportunity to obtain the project. Once you win the project, it is all yours to do as you wish- no middle man to deal with. Also you get to keep the client for ever without paying us another dime.</br></br>

Unlike other lead sites, we actually verify each lead before we post it. Most lead services just forward you emails directly from their contact form, so you end up with a lot of junk leads that you have to return. Wetroo lets you cherry pick per-qualified leads and just buy the ones you want - no contracts or monthly fees.");


--
-- Tabel structure for table `patients`
--
DROP TABLE  IF EXISTS `patients`;
CREATE TABLE `patients` (
  `patientid` int(11) NOT NULL AUTO_INCREMENT,
  `labid` int(11) NOT NULL,
  `fullname` varchar(256) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `alternative` varchar(100) NOT NULL,
  `email` varchar(256) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `pincode` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `datetime` varchar(50) NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`patientid`)
) ENGINE=InnoDB AUTO_INCREMENT=1004 DEFAULT CHARSET=latin1;

INSERT INTO `patients`  VALUES ( "1001","0","Rajni Jaiswal","9163803717","9123323919","rajnijaiswal990@gmail.com","Kolkata, West Bengal","Kolkata","700102","23 May, 2020","2020-05-23 13:18:31","N");
INSERT INTO `patients`  VALUES ( "1002","0","Tamal Bagchi","08961311235","9123323919","tamalbagchi@gmail.com","BH19/C Tirupati Apt. Jodakhana, Kestopur","Kolkata","700102","23 May, 2020","2020-05-23 13:28:21","Y");
INSERT INTO `patients`  VALUES ( "1003","0","Abhishek Das","8961311235","9123323919","tamalbagchi@gmail.com","BH19/C Tirupati Apt.","Kolkata","700102","23 May, 2020","2020-05-23 13:28:52","Y");


--
-- Tabel structure for table `staticpost`
--
DROP TABLE  IF EXISTS `staticpost`;
CREATE TABLE `staticpost` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `page_title` varchar(256) NOT NULL,
  `page_metatag` text NOT NULL,
  `page_keyword` text NOT NULL,
  `heading` varchar(256) NOT NULL,
  `picture` varchar(256) NOT NULL,
  `content` text NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `staticpost`  VALUES ( "3","0","","","","Heding Title","","Heding TitleHeding TitleHeding TitleHeding TitleHeding TitleHeding TitleHeding TitleHeding Title","Y");


--
-- Tabel structure for table `subcategory`
--
DROP TABLE  IF EXISTS `subcategory`;
CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `status` enum('Y','N') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;

INSERT INTO `subcategory`  VALUES ( "1","Amazon","2","Y");
INSERT INTO `subcategory`  VALUES ( "2","Flipkart","2","Y");
INSERT INTO `subcategory`  VALUES ( "3","Snapdeal","2","Y");
INSERT INTO `subcategory`  VALUES ( "4","Shopclues","2","Y");
INSERT INTO `subcategory`  VALUES ( "5","Paytm Mall","2","Y");
INSERT INTO `subcategory`  VALUES ( "6","Ebay","2","Y");
INSERT INTO `subcategory`  VALUES ( "7","Tatacliq","2","Y");
INSERT INTO `subcategory`  VALUES ( "8","Aliexpress","2","Y");
INSERT INTO `subcategory`  VALUES ( "9","Home Town","2","Y");
INSERT INTO `subcategory`  VALUES ( "10","Rediff Shop","2","Y");
INSERT INTO `subcategory`  VALUES ( "11","Choma","2","Y");
INSERT INTO `subcategory`  VALUES ( "12","Naaptol","2","Y");
INSERT INTO `subcategory`  VALUES ( "13","Pepperfry","2","Y");
INSERT INTO `subcategory`  VALUES ( "14","Urban Ladder","2","Y");
INSERT INTO `subcategory`  VALUES ( "15","Brand Factory","2","Y");
INSERT INTO `subcategory`  VALUES ( "16","Decathlon","2","Y");
INSERT INTO `subcategory`  VALUES ( "17","Myntra","3","Y");
INSERT INTO `subcategory`  VALUES ( "18","Ajio","3","Y");
INSERT INTO `subcategory`  VALUES ( "19","Jabong","3","Y");
INSERT INTO `subcategory`  VALUES ( "20","Fashion and You","3","Y");
INSERT INTO `subcategory`  VALUES ( "21","Yepme","3","Y");
INSERT INTO `subcategory`  VALUES ( "22","Voonik","3","Y");
INSERT INTO `subcategory`  VALUES ( "23","Crafts Villa","3","Y");
INSERT INTO `subcategory`  VALUES ( "24","Lime Road","3","Y");
INSERT INTO `subcategory`  VALUES ( "25","Basics Life","3","Y");
INSERT INTO `subcategory`  VALUES ( "26","First Cry","3","Y");
INSERT INTO `subcategory`  VALUES ( "27","Abof","3","Y");
INSERT INTO `subcategory`  VALUES ( "28","Fynd","3","Y");
INSERT INTO `subcategory`  VALUES ( "29","Hopscotch","3","Y");
INSERT INTO `subcategory`  VALUES ( "30","Coolwinks","3","Y");
INSERT INTO `subcategory`  VALUES ( "31","Lenskart","3","Y");
INSERT INTO `subcategory`  VALUES ( "32","Zomato","4","Y");
INSERT INTO `subcategory`  VALUES ( "33","Swiggy","4","Y");
INSERT INTO `subcategory`  VALUES ( "34","Food Pandas","4","Y");
INSERT INTO `subcategory`  VALUES ( "35","KFC","4","Y");
INSERT INTO `subcategory`  VALUES ( "36","McDonald","4","Y");
INSERT INTO `subcategory`  VALUES ( "37","Dominos","4","Y");
INSERT INTO `subcategory`  VALUES ( "38","Big Basket","4","Y");
INSERT INTO `subcategory`  VALUES ( "39","Just Eat","4","Y");
INSERT INTO `subcategory`  VALUES ( "40","Pizza Hut","4","Y");
INSERT INTO `subcategory`  VALUES ( "41","Haldirams","4","Y");
INSERT INTO `subcategory`  VALUES ( "42","Fresh Menu","4","Y");
INSERT INTO `subcategory`  VALUES ( "43","Burgerking","4","Y");
INSERT INTO `subcategory`  VALUES ( "44","Make My Trip","5","Y");
INSERT INTO `subcategory`  VALUES ( "45","Oyo","5","Y");
INSERT INTO `subcategory`  VALUES ( "46","Goibibo","5","Y");
INSERT INTO `subcategory`  VALUES ( "47","Yatra","5","Y");
INSERT INTO `subcategory`  VALUES ( "48","IRCTC","5","Y");
INSERT INTO `subcategory`  VALUES ( "49","Redbus","5","Y");
INSERT INTO `subcategory`  VALUES ( "50","Trivago","5","Y");
INSERT INTO `subcategory`  VALUES ( "51","Zoom Car","5","Y");
INSERT INTO `subcategory`  VALUES ( "52","Ola","5","Y");
INSERT INTO `subcategory`  VALUES ( "53","Uber","5","Y");
INSERT INTO `subcategory`  VALUES ( "54","Ease My Trip","5","Y");
INSERT INTO `subcategory`  VALUES ( "55","Agoda","5","Y");
INSERT INTO `subcategory`  VALUES ( "56","My Busticets","5","Y");
INSERT INTO `subcategory`  VALUES ( "57","Ticket Goose","5","Y");
INSERT INTO `subcategory`  VALUES ( "58","Travel Guru","5","Y");
INSERT INTO `subcategory`  VALUES ( "59","Musa Fir","5","Y");
INSERT INTO `subcategory`  VALUES ( "60","Hotels.com","5","Y");
INSERT INTO `subcategory`  VALUES ( "61","Clear Tip","5","Y");
INSERT INTO `subcategory`  VALUES ( "62","Paytm","6","Y");
INSERT INTO `subcategory`  VALUES ( "63","Mobikwik","6","Y");
INSERT INTO `subcategory`  VALUES ( "64","Jio","6","Y");
INSERT INTO `subcategory`  VALUES ( "65","Airtel","6","Y");
INSERT INTO `subcategory`  VALUES ( "66","Freecharge","6","Y");
INSERT INTO `subcategory`  VALUES ( "67","Dish TV","6","Y");
INSERT INTO `subcategory`  VALUES ( "68","TATA Sky","6","Y");
INSERT INTO `subcategory`  VALUES ( "69","Recharge It Now","6","Y");
INSERT INTO `subcategory`  VALUES ( "70","Book My Show","7","Y");
INSERT INTO `subcategory`  VALUES ( "71","Just Tickets","7","Y");
INSERT INTO `subcategory`  VALUES ( "72","Inox","7","Y");
INSERT INTO `subcategory`  VALUES ( "73","Ticket New","7","Y");
INSERT INTO `subcategory`  VALUES ( "74","Ticket Please","7","Y");
INSERT INTO `subcategory`  VALUES ( "75","PVR","7","Y");
INSERT INTO `subcategory`  VALUES ( "76","Paytm","7","Y");
INSERT INTO `subcategory`  VALUES ( "77","Pharmeasy","8","Y");
INSERT INTO `subcategory`  VALUES ( "78","Medilife","8","Y");
INSERT INTO `subcategory`  VALUES ( "79","1MG","8","Y");
INSERT INTO `subcategory`  VALUES ( "80","Netmeds","8","Y");
INSERT INTO `subcategory`  VALUES ( "81","Sasta Sundar","8","Y");
INSERT INTO `subcategory`  VALUES ( "82","Aermed","8","Y");
INSERT INTO `subcategory`  VALUES ( "83","Medplus","8","Y");
INSERT INTO `subcategory`  VALUES ( "84","Practo","8","Y");


--
-- Tabel structure for table `subscription`
--
DROP TABLE  IF EXISTS `subscription`;
CREATE TABLE `subscription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_period` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `applied_offer` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `datetime` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subscribe_date` date NOT NULL,
  `start_datetime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiry_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Y','N') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `subscription`  VALUES ( "1","1","09 November, 2019","Subscribe","N/A","","599","PayUMoney","N","2019-11-09 02:02:09","2019-11-09","","","N");
INSERT INTO `subscription`  VALUES ( "2","1","09 November, 2019","Subscribe","N/A","","399","PayUMoney","N","2019-11-09 02:06:32","2019-11-09","","","N");
INSERT INTO `subscription`  VALUES ( "3","1","09 November, 2019","Subscribe","N/A","","99","PayUMoney","N","2019-11-09 02:08:10","2019-11-09","2019-11-09 13:38:40","2020-02-07 13:38:40","N");
INSERT INTO `subscription`  VALUES ( "4","1","09 November, 2019","Subscribe","N/A","","399","PayUMoney","Y","2019-11-09 02:57:16","2019-11-09","2019-11-09 14:30:38","2020-11-08 14:30:38","Y");
INSERT INTO `subscription`  VALUES ( "5","1","11 November, 2019","Subscribe","N/A","","","PayUMoney","N","2019-11-10 22:36:51","2019-11-11","","","N");
INSERT INTO `subscription`  VALUES ( "6","1","11 November, 2019","Subscribe","N/A","","199","PayUMoney","N","2019-11-10 22:37:19","2019-11-11","","","N");


--
-- Tabel structure for table `test_reports`
--
DROP TABLE  IF EXISTS `test_reports`;
CREATE TABLE `test_reports` (
  `reportid` int(11) NOT NULL AUTO_INCREMENT,
  `test` varchar(256) NOT NULL,
  `patient_name` varchar(256) NOT NULL,
  `labid` int(11) NOT NULL,
  `notes` text NOT NULL,
  `sale_fee` varchar(50) NOT NULL,
  `report_date` varchar(100) NOT NULL,
  `document` varchar(256) NOT NULL,
  `date` varchar(256) NOT NULL,
  `datetime` varchar(256) NOT NULL,
  `status` enum('P','I','C','D') NOT NULL DEFAULT 'P',
  PRIMARY KEY (`reportid`)
) ENGINE=InnoDB AUTO_INCREMENT=1004 DEFAULT CHARSET=latin1;

INSERT INTO `test_reports`  VALUES ( "1000","367223","1002","0","hgfhgfhgfh hgfhgfhgfh","fghfgh hgfhgfhgfh","fghgfh hgfhgfhgfh","f30433046baee465d54ebbe841f7dd4cSANITIZATION WEBSITE CONTENT .docx","23 May, 2020","2020-05-23 17:44:41","D");
INSERT INTO `test_reports`  VALUES ( "1001","367223","1002","0","sdf sdfsd fsd","sd fsdf","sd fdsf","6184397dddb99b60a5b5fd60cac04ef0New Doc 2020-05-18 20.36.46_1.jpg","23 May, 2020","2020-05-23 17:53:49","I");
INSERT INTO `test_reports`  VALUES ( "1002","367223","1002","0","d fsd fsdf","100","25 May 2020","New Doc 2020-05-18 20.36.46_1.jpg","23 May, 2020","2020-05-23 18:19:39","P");
INSERT INTO `test_reports`  VALUES ( "1003","367223","1002","1"," gfhfgh fgh","f ghgfh ","fg hgfh f","60b7b0db-5e09-44df-8a8f-9edabce43610.jpg","23 May, 2020","2020-05-23 20:46:49","I");


--
-- Tabel structure for table `transaction`
--
DROP TABLE  IF EXISTS `transaction`;
CREATE TABLE `transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `subscription_id` int(11) NOT NULL,
  `isConsentPayment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mihpayid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unmappedstatus` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `response_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `txnid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `addedon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productinfo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zipcode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `udf1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `udf2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `udf3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `udf4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `udf5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `udf6` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `udf7` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `udf8` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `udf9` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `udf10` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hash` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `field1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field6` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field7` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field8` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field9` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `PG_TYPE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encryptedPaymentId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_ref_num` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bankcode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `error` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `error_Message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_on_card` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cardnum` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cardhash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount_split` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payuMoneyId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `net_amount_debit` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `transaction`  VALUES ( "1","1","3","0","9083677702","CC","success","captured","ucknRavX","752d25710045e9db9f2f","99.00","2019-11-09 13:38:40","Subscribe","Tamal","","","","","","","","tamal@cloudsire.com","8961311235","","","","","","","","","","","a7e72499d16c3c0b85da33ed540190965f009642d08f63b61bc11c5caab00b8d80791d6fa35bd71c7811509ce07a774830a43aa97d72f258dbc5cb98ea7bc6cc","578094","719981","203009","0","817259880520","00","AUCPOSITIVE","Approved or completed successfully","No Error","AXISPG","99EB2E4AE4491E428B67A5538C4A423A","578094","MAST","E000","No Error","anything","512345XXXXXX2346","This field is no longer supported in postback params.","{"PAYU":"99.00"}","249946653","0.00","99");
INSERT INTO `transaction`  VALUES ( "2","1","4","0","9083677735","CC","success","captured","ucknRavX","73ee06f79e9b634f9402","399.00","2019-11-09 14:30:38","Subscribe","Tamal","","","","","","","","tamal@cloudsire.com","8961311235","","","","","","","","","","","d07af713b4ba3a5bbc4dfd1906424e743c7468f5a0a2bbe5fd3117c44e2af65191eba5b18f827aeed508a98527e0b65f8e01421198a0cde4616b7f7b57ecc49c","816510","645313","203009","0","234107215650","00","AUCPOSITIVE","Approved or completed successfully","No Error","AXISPG","9660344E930BD1988A34C5E5789A7CC2","816510","MAST","E000","No Error","anything","512345XXXXXX2346","This field is no longer supported in postback params.","{"PAYU":"399.00"}","249946705","0.00","399");


--
-- Tabel structure for table `user_register`
--
DROP TABLE  IF EXISTS `user_register`;
CREATE TABLE `user_register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(256) NOT NULL,
  `company` varchar(256) NOT NULL,
  `website` varchar(256) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(256) NOT NULL,
  `skills` text NOT NULL,
  `password` varchar(256) NOT NULL,
  `country` varchar(50) NOT NULL,
  `profile_pic` varchar(256) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zip` varchar(100) NOT NULL,
  `txnid` int(25) NOT NULL,
  `credits` int(50) NOT NULL,
  `start_date` varchar(256) NOT NULL,
  `expiry_date` varchar(256) NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `datetime` varchar(100) NOT NULL,
  `continent` varchar(256) NOT NULL,
  `latitude` varchar(256) NOT NULL,
  `longitude` varchar(256) NOT NULL,
  `ip_address` varchar(256) NOT NULL,
  `browser` varchar(256) NOT NULL,
  `location` varchar(256) NOT NULL,
  `reference_id` varchar(50) NOT NULL,
  `reference_date` varchar(50) NOT NULL,
  `active_account` text NOT NULL,
  `forgot_token` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8843143 DEFAULT CHARSET=latin1;

INSERT INTO `user_register`  VALUES ( "1","Tamal Bagchi","","","8961311235","tamalbagchi@gmail.com","","96e79218965eb72c92a549dd5a330112","105","","","","","","0","100081","","","Y","08 December, 2019","","","","","","","","","","");
INSERT INTO `user_register`  VALUES ( "2","Amitabha Kundu","WebMantra","http://www.bhkhomes.com","08961311235","adi.webmantra@gmail.com","PHP, MySQL, Ajax, JavaScript","96e79218965eb72c92a549dd5a330112","1","1761550.jpg","BH19/C Tirupati Apt., Jodakhana, Kestopur","Kolkata","West Bengal","700102","0","100419","","","Y","09 December, 2019","","","","","","","","","","");
INSERT INTO `user_register`  VALUES ( "6613823","Tamal Bagchi","","","08961311235","info@webmantratech.com","","96e79218965eb72c92a549dd5a330112","","","","","","","0","350","","","N","17 December, 2019","","","","","","","","","NTA3MzMxMTg=","MzY5OTk2NDY2");
INSERT INTO `user_register`  VALUES ( "7480689","Tamal Bagchi","","","8961311235","career.cloudsire@gmail.com","","96e79218965eb72c92a549dd5a330112","","","","","","","0","100","","","Y","19 December, 2019","","","","","","","2","19 December, 2019","ODAyNTQxOTU=","");


--
-- Tabel structure for table `visitor`
--
DROP TABLE  IF EXISTS `visitor`;
CREATE TABLE `visitor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` varchar(256) NOT NULL,
  `again` varchar(256) NOT NULL,
  `IP` varchar(256) NOT NULL,
  `browser` varchar(256) NOT NULL,
  `OS` varchar(256) NOT NULL,
  `date` varchar(100) NOT NULL,
  `country_from` varchar(50) NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=latin1;

INSERT INTO `visitor`  VALUES ( "1","26 Dec, 2019 5:27 AM","No","172.69.134.158","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","26 December, 2019","Singapore","Y");
INSERT INTO `visitor`  VALUES ( "2","26 Dec, 2019 5:27 AM","No","172.69.135.233","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","26 December, 2019","Singapore","Y");
INSERT INTO `visitor`  VALUES ( "3","26 Dec, 2019 5:27 AM","No","141.101.77.85","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36","Direct access","26 December, 2019","Netherlands","Y");
INSERT INTO `visitor`  VALUES ( "4","26 Dec, 2019 5:31 AM","Yes","172.69.134.158","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","26 December, 2019","Singapore","Y");
INSERT INTO `visitor`  VALUES ( "5","26 Dec, 2019 6:27 AM","No","141.101.77.43","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","Direct access","26 December, 2019","Netherlands","Y");
INSERT INTO `visitor`  VALUES ( "6","26 Dec, 2019 6:27 AM","No","162.158.111.150","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","Direct access","26 December, 2019","Netherlands","Y");
INSERT INTO `visitor`  VALUES ( "7","26 Dec, 2019 6:42 AM","No","141.101.104.106","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","Direct access","26 December, 2019","Netherlands","Y");
INSERT INTO `visitor`  VALUES ( "8","26 Dec, 2019 8:25 AM","No","172.68.254.173","Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)","Direct access","26 December, 2019","Hong Kong","Y");
INSERT INTO `visitor`  VALUES ( "9","26 Dec, 2019 8:31 AM","No","162.158.106.101","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","Direct access","26 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "10","26 Dec, 2019 8:47 AM","No","108.162.246.112","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","Direct access","26 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "11","26 Dec, 2019 9:50 AM","No","108.162.219.55","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36","Direct access","26 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "12","26 Dec, 2019 11:56 AM","No","172.69.54.248","python-requests/2.22.0","Direct access","26 December, 2019","Netherlands","Y");
INSERT INTO `visitor`  VALUES ( "13","26 Dec, 2019 12:45 PM","No","162.158.106.89","Mozilla/5.0 (compatible; CloudFlare-AlwaysOnline/1.0; +http://www.cloudflare.com/always-online) AppleWebKit/534.34","Direct access","26 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "14","26 Dec, 2019 12:47 PM","No","162.158.107.234","Mozilla/5.0 (compatible; CloudFlare-AlwaysOnline/1.0; +http://www.cloudflare.com/always-online) AppleWebKit/534.34","Direct access","26 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "15","26 Dec, 2019 13:47 PM","No","162.158.154.186","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","26 December, 2019","United Kingdom","Y");
INSERT INTO `visitor`  VALUES ( "16","26 Dec, 2019 13:50 PM","No","162.158.107.230","Mozilla/5.0 (Windows NT 10.0; Win64; x64)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36","Direct access","26 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "17","26 Dec, 2019 13:50 PM","No","162.158.106.71","Go-http-client/1.1","Direct access","26 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "18","26 Dec, 2019 15:53 PM","Yes","162.158.107.234","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","Direct access","26 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "19","26 Dec, 2019 15:53 PM","No","162.158.107.166","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","Direct access","26 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "20","26 Dec, 2019 18:34 PM","No","162.158.167.23","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","26 December, 2019","Singapore","Y");
INSERT INTO `visitor`  VALUES ( "21","27 Dec, 2019 3:56 AM","No","162.158.111.222","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","Direct access","27 December, 2019","Netherlands","Y");
INSERT INTO `visitor`  VALUES ( "22","27 Dec, 2019 3:56 AM","No","172.69.55.201","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","Direct access","27 December, 2019","Netherlands","Y");
INSERT INTO `visitor`  VALUES ( "23","27 Dec, 2019 4:11 AM","No","141.101.104.154","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","Direct access","27 December, 2019","Netherlands","Y");
INSERT INTO `visitor`  VALUES ( "24","27 Dec, 2019 4:16 AM","No","162.158.167.159","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","27 December, 2019","Singapore","Y");
INSERT INTO `visitor`  VALUES ( "25","27 Dec, 2019 4:16 AM","No","172.69.63.210","Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0","Direct access","27 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "26","27 Dec, 2019 4:16 AM","No","172.68.65.131","Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0","Direct access","27 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "27","27 Dec, 2019 5:50 AM","No","162.158.63.7","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36","Direct access","27 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "28","27 Dec, 2019 6:43 AM","No","141.101.104.64","python-requests/2.22.0","Direct access","27 December, 2019","Netherlands","Y");
INSERT INTO `visitor`  VALUES ( "29","27 Dec, 2019 15:55 PM","Yes","162.158.107.166","Mozilla/5.0 (Windows NT 10.0; Win64; x64)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36","Direct access","27 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "30","27 Dec, 2019 15:55 PM","No","162.158.107.178","Go-http-client/1.1","Direct access","27 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "31","27 Dec, 2019 16:11 PM","Yes","162.158.107.166","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","Direct access","27 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "32","27 Dec, 2019 16:11 PM","Yes","162.158.106.101","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","Direct access","27 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "33","27 Dec, 2019 18:34 PM","Yes","172.69.134.158","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","27 December, 2019","Singapore","Y");
INSERT INTO `visitor`  VALUES ( "34","27 Dec, 2019 18:35 PM","Yes","172.69.134.158","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","27 December, 2019","Singapore","Y");
INSERT INTO `visitor`  VALUES ( "35","27 Dec, 2019 22:03 PM","No","172.69.135.211","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","27 December, 2019","Singapore","Y");
INSERT INTO `visitor`  VALUES ( "36","27 Dec, 2019 22:06 PM","Yes","172.69.135.211","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","27 December, 2019","Singapore","Y");
INSERT INTO `visitor`  VALUES ( "37","28 Dec, 2019 2:47 AM","No","162.158.63.95","python-requests/2.22.0","Direct access","28 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "38","28 Dec, 2019 5:54 AM","No","209.17.96.42","Mozilla/5.0 (compatible; Nimbostratus-Bot/v1.3.2; http://cloudsystemnetworks.com)","Direct access","28 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "39","28 Dec, 2019 6:01 AM","No","108.162.221.201","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/[WEBKIT_VERSION] (KHTML, like Gecko, Mediapartners-Google) Chrome/[CHROME_VERSION] Safari/[WEBKIT_VERSION]","Direct access","28 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "40","28 Dec, 2019 6:01 AM","No","172.69.69.117","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/[WEBKIT_VERSION] (KHTML, like Gecko, Mediapartners-Google) Chrome/[CHROME_VERSION] Safari/[WEBKIT_VERSION]","Direct access","28 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "41","28 Dec, 2019 6:01 AM","Yes","108.162.221.201","Mozilla/5.0 (Linux; Android 4.0.4; Galaxy Nexus Build/IMM76B) AppleWebKit/[WEBKIT_VERSION] (KHTML, like Gecko; Mediapartners-Google) Chrome/[CHROME_VERSION] Mobile Safari/[WEBKIT_VERSION]","Direct access","28 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "42","28 Dec, 2019 6:01 AM","Yes","172.69.69.117","Mozilla/5.0 (Linux; Android 4.0.4; Galaxy Nexus Build/IMM76B) AppleWebKit/[WEBKIT_VERSION] (KHTML, like Gecko; Mediapartners-Google) Chrome/[CHROME_VERSION] Mobile Safari/[WEBKIT_VERSION]","Direct access","28 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "43","28 Dec, 2019 6:42 AM","No","162.158.155.115","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","28 December, 2019","United Kingdom","Y");
INSERT INTO `visitor`  VALUES ( "44","28 Dec, 2019 12:27 PM","Yes","162.158.106.89","Mozilla/5.0 (Windows NT 10.0; Win64; x64)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36","Direct access","28 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "45","28 Dec, 2019 12:27 PM","No","108.162.245.123","Go-http-client/1.1","Direct access","28 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "46","28 Dec, 2019 12:57 PM","No","172.69.68.140","Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)","Direct access","28 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "47","28 Dec, 2019 13:01 PM","Yes","108.162.221.201","Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)","Direct access","28 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "48","28 Dec, 2019 13:02 PM","No","162.158.63.49","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36","Direct access","28 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "49","28 Dec, 2019 14:06 PM","Yes","162.158.155.115","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","28 December, 2019","United Kingdom","Y");
INSERT INTO `visitor`  VALUES ( "50","28 Dec, 2019 16:07 PM","Yes","108.162.221.201","Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)","Direct access","28 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "51","28 Dec, 2019 19:09 PM","No","162.158.158.32","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","28 December, 2019","United Kingdom","Y");
INSERT INTO `visitor`  VALUES ( "52","28 Dec, 2019 21:19 PM","No","162.158.106.23","Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)","Direct access","28 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "53","28 Dec, 2019 22:01 PM","No","172.68.102.103","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36","Direct access","28 December, 2019","Portugal","Y");
INSERT INTO `visitor`  VALUES ( "54","28 Dec, 2019 22:39 PM","No","162.158.106.185","Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)","Direct access","28 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "55","29 Dec, 2019 1:43 AM","No","172.69.10.123","Mozilla/5.0 (Windows NT 5.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36","Direct access","29 December, 2019","Russia","Y");
INSERT INTO `visitor`  VALUES ( "56","29 Dec, 2019 5:57 AM","No","108.162.219.149","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36","Direct access","29 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "57","29 Dec, 2019 11:37 AM","Yes","162.158.154.186","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","29 December, 2019","United Kingdom","Y");
INSERT INTO `visitor`  VALUES ( "58","29 Dec, 2019 14:52 PM","Yes","162.158.106.101","Mozilla/5.0 (Windows NT 10.0; Win64; x64)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36","Direct access","29 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "59","29 Dec, 2019 14:52 PM","No","162.158.107.170","Go-http-client/1.1","Direct access","29 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "60","29 Dec, 2019 15:07 PM","No","162.158.92.135","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36 Kinza/4.7.2","Direct access","29 December, 2019","Germany","Y");
INSERT INTO `visitor`  VALUES ( "61","29 Dec, 2019 17:36 PM","No","162.158.93.62","python-requests/2.22.0","Direct access","29 December, 2019","Germany","Y");
INSERT INTO `visitor`  VALUES ( "62","29 Dec, 2019 20:51 PM","No","162.158.62.248","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36 OPR/52.0.2871.64","Direct access","29 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "63","29 Dec, 2019 22:48 PM","No","162.158.93.194","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36 OPR/54.0.2952.54","Direct access","29 December, 2019","Germany","Y");
INSERT INTO `visitor`  VALUES ( "64","29 Dec, 2019 23:40 PM","Yes","162.158.92.135","Mozilla/5.0 zgrab/0.x (compatible; Researchscan/t12sns; +http://researchscan.comsys.rwth-aachen.de)","Direct access","29 December, 2019","Germany","Y");
INSERT INTO `visitor`  VALUES ( "65","30 Dec, 2019 2:38 AM","No","172.68.189.78","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko; compatible; BuiltWith/1.0; +http://builtwith.com/biup) Chrome/74.0.3729.131 Safari/537.36","Direct access","30 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "66","30 Dec, 2019 3:18 AM","No","162.158.88.139","Mozilla/5.0 zgrab/0.x (compatible; Researchscan/t12ca; +http://researchscan.comsys.rwth-aachen.de)","Direct access","30 December, 2019","Germany","Y");
INSERT INTO `visitor`  VALUES ( "67","30 Dec, 2019 4:48 AM","No","141.101.99.148","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","30 December, 2019","United Kingdom","Y");
INSERT INTO `visitor`  VALUES ( "68","30 Dec, 2019 5:13 AM","Yes","162.158.158.32","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","30 December, 2019","United Kingdom","Y");
INSERT INTO `visitor`  VALUES ( "69","30 Dec, 2019 5:16 AM","Yes","162.158.158.32","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","30 December, 2019","United Kingdom","Y");
INSERT INTO `visitor`  VALUES ( "70","30 Dec, 2019 5:37 AM","No","162.158.94.7","Go-http-client/1.1","Direct access","30 December, 2019","Germany","Y");
INSERT INTO `visitor`  VALUES ( "71","30 Dec, 2019 5:58 AM","No","162.158.158.146","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","30 December, 2019","United Kingdom","Y");
INSERT INTO `visitor`  VALUES ( "72","30 Dec, 2019 7:12 AM","No","162.158.63.197","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36","Direct access","30 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "73","30 Dec, 2019 9:42 AM","No","172.68.65.173","","Direct access","30 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "74","30 Dec, 2019 12:53 PM","No","162.158.106.167","Mozilla/5.0 (Windows NT 10.0; Win64; x64)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36","Direct access","30 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "75","30 Dec, 2019 12:53 PM","No","162.158.106.143","Go-http-client/1.1","Direct access","30 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "76","30 Dec, 2019 19:14 PM","No","162.158.158.8","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","30 December, 2019","United Kingdom","Y");
INSERT INTO `visitor`  VALUES ( "77","31 Dec, 2019 4:41 AM","Yes","162.158.158.32","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","31 December, 2019","United Kingdom","Y");
INSERT INTO `visitor`  VALUES ( "78","31 Dec, 2019 4:44 AM","Yes","162.158.158.32","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36","Direct access","31 December, 2019","United Kingdom","Y");
INSERT INTO `visitor`  VALUES ( "79","31 Dec, 2019 4:56 AM","Yes","162.158.106.23","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/[WEBKIT_VERSION] (KHTML, like Gecko, Mediapartners-Google) Chrome/[CHROME_VERSION] Safari/[WEBKIT_VERSION]","Direct access","31 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "80","31 Dec, 2019 4:56 AM","No","162.158.106.131","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/[WEBKIT_VERSION] (KHTML, like Gecko, Mediapartners-Google) Chrome/[CHROME_VERSION] Safari/[WEBKIT_VERSION]","Direct access","31 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "81","31 Dec, 2019 4:56 AM","Yes","162.158.106.23","Mozilla/5.0 (Linux; Android 4.0.4; Galaxy Nexus Build/IMM76B) AppleWebKit/[WEBKIT_VERSION] (KHTML, like Gecko; Mediapartners-Google) Chrome/[CHROME_VERSION] Mobile Safari/[WEBKIT_VERSION]","Direct access","31 December, 2019","United States","Y");
INSERT INTO `visitor`  VALUES ( "82","31 Dec, 2019 4:56 AM","Yes","162.158.106.131","Mozilla/5.0 (Linux; Android 4.0.4; Galaxy Nexus Build/IMM76B) AppleWebKit/[WEBKIT_VERSION] (KHTML, like Gecko; Mediapartners-Google) Chrome/[CHROME_VERSION] Mobile Safari/[WEBKIT_VERSION]","Direct access","31 December, 2019","United States","Y");


--
-- Tabel structure for table `website_settings`
--
DROP TABLE  IF EXISTS `website_settings`;
CREATE TABLE `website_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL,
  `metadesc` varchar(256) NOT NULL,
  `metatag` varchar(256) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(100) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `name` varchar(256) NOT NULL,
  `phone` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `paypalmail` varchar(256) NOT NULL,
  `profile` varchar(256) NOT NULL,
  `logo` varchar(256) NOT NULL,
  `favicon` varchar(256) NOT NULL,
  `our_commission_in` int(11) NOT NULL,
  `location` varchar(256) NOT NULL,
  `currency` varchar(256) NOT NULL,
  `unit_system` varchar(256) NOT NULL,
  `weight_unit` varchar(256) NOT NULL,
  `store_description` text NOT NULL,
  `webstatus` enum('Y','N') NOT NULL DEFAULT 'Y',
  `shipping_rate` varchar(256) NOT NULL,
  `facebook` text NOT NULL,
  `twitter` text NOT NULL,
  `rssfeed` text NOT NULL,
  `dorrable` text NOT NULL,
  `googleplus` text NOT NULL,
  `pintest` text NOT NULL,
  `linkedin` text NOT NULL,
  `youtube` text NOT NULL,
  `page_title` varchar(256) NOT NULL,
  `page_description` text NOT NULL,
  `page_keyword` text NOT NULL,
  `refund_policy` text NOT NULL,
  `privacy_policy` text NOT NULL,
  `merchant_key` varchar(256) NOT NULL DEFAULT '0',
  `salt` varchar(256) NOT NULL DEFAULT '0',
  `terms` text NOT NULL,
  `live_exchange` int(11) NOT NULL,
  `last_exchange_date` varchar(50) NOT NULL,
  `shutdown` enum('Y','N') NOT NULL DEFAULT 'N',
  `date` varchar(256) NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `website_settings`  VALUES ( "1","","","","Mumbai, Maharashtra","105","700091","Maharashtra","Mumbai","Clinto Healthcare","+91 89613 11235","help@clinto.co.in","","5872171065-IMG_2529.png","745970logo.png","851147favicon.png","0","","","","","","Y","","https://www.facebook.com","https://www.twitter.com","","","https://www.instagram.com","","","https://www.youtube.com","Discount For Online Shopping | Next G Shopping","Discount For Online Shopping | Next G Shopping","Discount For Online Shopping | Next G Shopping","","","hDkYGPQe","yIEkykqEH3","","37735","2019/12/31","N","12 April, 2020","Y");


SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
